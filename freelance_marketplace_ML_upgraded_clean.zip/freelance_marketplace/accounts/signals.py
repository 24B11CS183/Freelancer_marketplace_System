from django.db.models.signals import post_save
from django.dispatch import receiver
from django.contrib.auth import get_user_model

User = get_user_model()

@receiver(post_save, sender=User)
def create_user_profile(sender, instance, created, **kwargs):
    """
    Signal handler to automatically create the appropriate profile
    (ClientProfile or FreelancerProfile) when a new User is created.
    """
    if created:
        if instance.role == 'client':
            from clients.models import ClientProfile
            ClientProfile.objects.get_or_create(user=instance)
        elif instance.role == 'freelancer':
            from freelancers.models import FreelancerProfile
            FreelancerProfile.objects.get_or_create(user=instance)


@receiver(post_save, sender=User)
def save_user_profile(sender, instance, **kwargs):
    """
    Signal handler to save the profile when the User is saved.
    """
    if instance.role == 'client':
        from clients.models import ClientProfile
        # Retrieve or create profile in case it wasn't created before
        profile, created = ClientProfile.objects.get_or_create(user=instance)
        profile.save()
    elif instance.role == 'freelancer':
        from freelancers.models import FreelancerProfile
        profile, created = FreelancerProfile.objects.get_or_create(user=instance)
        profile.save()
