from django import forms
from django.contrib.auth import get_user_model
from django.contrib.auth.forms import UserCreationForm, UserChangeForm

User = get_user_model()

class UserRegisterForm(UserCreationForm):
    """
    Form for custom user registration.
    Allows selection of role (Client vs Freelancer) and input of basic fields.
    """
    email = forms.EmailField(required=True, help_text="Required. A valid email address.")
    role = forms.ChoiceField(
        choices=User.ROLE_CHOICES,
        widget=forms.RadioSelect(attrs={'class': 'form-check-input'}),
        required=True,
        label="Join as a:"
    )

    class Meta(UserCreationForm.Meta):
        model = User
        fields = ('email', 'username', 'role', 'phone')

    def clean_email(self):
        email = self.cleaned_data.get('email')
        if User.objects.filter(email=email).exists():
            raise forms.ValidationError("A user with this email address already exists.")
        return email


class UserProfileForm(forms.ModelForm):
    """
    Form for updating basic user information (bio, phone, profile_picture).
    """
    class Meta:
        model = User
        fields = ('username', 'phone', 'profile_picture', 'bio')
        widgets = {
            'bio': forms.Textarea(attrs={'rows': 4, 'placeholder': 'Tell us about yourself...'}),
            'phone': forms.TextInput(attrs={'placeholder': '+1 (555) 123-4567'}),
        }
