from django.test import TestCase
from django.contrib.auth import get_user_model
from django.db.utils import IntegrityError

User = get_user_model()

class UserManagerTests(TestCase):
    """
    Test cases for custom User and UserManager models.
    """
    def test_create_user_with_email_successful(self):
        """
        Verify creating a regular user with email auth is successful.
        """
        user = User.objects.create_user(
            email='freelancer@example.com',
            username='freelancer_user',
            password='securepassword123',
            role='freelancer'
        )
        self.assertEqual(user.email, 'freelancer@example.com')
        self.assertEqual(user.username, 'freelancer_user')
        self.assertTrue(user.check_password('securepassword123'))
        self.assertEqual(user.role, 'freelancer')
        self.assertTrue(user.is_active)
        self.assertFalse(user.is_staff)
        self.assertFalse(user.is_superuser)

    def test_create_superuser_successful(self):
        """
        Verify creating a superuser is successful.
        """
        admin_user = User.objects.create_superuser(
            email='admin@example.com',
            username='admin_user',
            password='adminpassword123'
        )
        self.assertEqual(admin_user.email, 'admin@example.com')
        self.assertTrue(admin_user.is_staff)
        self.assertTrue(admin_user.is_superuser)

    def test_create_user_no_email_raises_error(self):
        """
        Verify creating a user without email raises ValueError.
        """
        with self.assertRaises(ValueError):
            User.objects.create_user(
                email='',
                username='invalid_user',
                password='somepassword123'
            )

    def test_duplicate_email_raises_error(self):
        """
        Verify that creating users with duplicate emails raises IntegrityError.
        """
        User.objects.create_user(
            email='duplicate@example.com',
            username='user1',
            password='password123'
        )
        with self.assertRaises(Exception):  # Generic exception check for DB constraints
            User.objects.create_user(
                email='duplicate@example.com',
                username='user2',
                password='password456'
            )
