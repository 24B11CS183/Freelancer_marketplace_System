def user_role_context(request):
    """
    Context processor to inject the correctly detected user role
    ('admin', 'client', 'freelancer', or None) into all templates.
    """
    if request.user.is_authenticated:
        if request.user.is_superuser or request.user.is_staff:
            role = 'admin'
        else:
            role = request.user.role
        return {'detected_user_role': role}
    return {'detected_user_role': None}
