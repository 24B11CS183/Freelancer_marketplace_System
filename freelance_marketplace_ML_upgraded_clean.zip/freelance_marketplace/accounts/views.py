from django.contrib.auth import get_user_model
from django.contrib.auth.views import (
    LoginView, LogoutView, PasswordChangeView, 
    PasswordResetView, PasswordResetDoneView, 
    PasswordResetConfirmView, PasswordResetCompleteView
)
from django.urls import reverse_lazy
from django.views.generic import CreateView, UpdateView, RedirectView
from django.contrib.auth.mixins import LoginRequiredMixin
from django.contrib import messages
from .forms import UserRegisterForm, UserProfileForm

User = get_user_model()

class RegisterView(CreateView):
    """
    Handles user registration using the custom registration form.
    """
    model = User
    form_class = UserRegisterForm
    template_name = 'accounts/register.html'
    success_url = reverse_lazy('accounts:login')

    def form_valid(self, form):
        response = super().form_valid(form)
        messages.success(self.request, "Registration successful! You can now log in.")
        return response


class UserLoginView(LoginView):
    """
    Handles user login, redirecting authenticated users to the role selector dashboard.
    """
    template_name = 'accounts/login.html'
    redirect_authenticated_user = True
    
    def get_success_url(self):
        return reverse_lazy('accounts:dashboard_redirect')


class UserLogoutView(LogoutView):
    """
    Logs out the user and redirects to home.
    """
    next_page = reverse_lazy('home')
    
    def dispatch(self, request, *args, **kwargs):
        if request.user.is_authenticated:
            messages.info(request, "You have been logged out.")
        return super().dispatch(request, *args, **kwargs)


class DashboardRedirectView(LoginRequiredMixin, RedirectView):
    """
    Redirects user to the correct dashboard depending on their role.
    """
    permanent = False
    
    def get_redirect_url(self, *args, **kwargs):
        if self.request.user.is_staff or self.request.user.is_superuser:
            return reverse_lazy('admin_dashboard:dashboard')
        elif self.request.user.role == 'client':
            return reverse_lazy('clients:dashboard')
        elif self.request.user.role == 'freelancer':
            return reverse_lazy('freelancers:dashboard')
        return reverse_lazy('home')


class ProfileEditView(LoginRequiredMixin, UpdateView):
    """
    Updates basic user accounts details.
    """
    model = User
    form_class = UserProfileForm
    template_name = 'accounts/profile_edit.html'
    success_url = reverse_lazy('accounts:profile_edit')

    def get_object(self, queryset=None):
        return self.request.user

    def form_valid(self, form):
        messages.success(self.request, "Account profile updated successfully.")
        return super().form_valid(form)


class UserPasswordChangeView(LoginRequiredMixin, PasswordChangeView):
    """
    Enables users to change their password once logged in.
    """
    template_name = 'accounts/password_change.html'
    success_url = reverse_lazy('accounts:dashboard_redirect')
    
    def form_valid(self, form):
        messages.success(self.request, "Password changed successfully.")
        return super().form_valid(form)


class UserPasswordResetView(PasswordResetView):
    """
    Allows user to request password reset email.
    """
    template_name = 'accounts/password_reset.html'
    email_template_name = 'accounts/password_reset_email.html'
    subject_template_name = 'accounts/password_reset_subject.txt'
    success_url = reverse_lazy('accounts:password_reset_done')


class UserPasswordResetDoneView(PasswordResetDoneView):
    """
    Displays page indicating a password reset email was sent.
    """
    template_name = 'accounts/password_reset_done.html'


class UserPasswordResetConfirmView(PasswordResetConfirmView):
    """
    Allows user to set a new password via the secure email link.
    """
    template_name = 'accounts/password_reset_confirm.html'
    success_url = reverse_lazy('accounts:password_reset_complete')


class UserPasswordResetCompleteView(PasswordResetCompleteView):
    """
    Displays page confirming the password reset is complete.
    """
    template_name = 'accounts/password_reset_complete.html'
