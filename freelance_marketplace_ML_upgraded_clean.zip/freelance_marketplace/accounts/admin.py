from django.contrib import admin
from django.contrib.auth.admin import UserAdmin
from .models import User

class CustomUserAdmin(UserAdmin):
    """
    Custom Admin configuration for the custom User model.
    Inherits from UserAdmin to preserve standard authentication management controls.
    """
    model = User
    list_display = ['email', 'username', 'role', 'phone', 'is_staff', 'created_at']
    list_filter = ['role', 'is_staff', 'is_superuser', 'is_active']
    search_fields = ['email', 'username', 'phone']
    ordering = ['-created_at']
    
    # Include custom fields in the edit and create forms
    fieldsets = UserAdmin.fieldsets + (
        ('Custom Profile Info', {
            'fields': ('role', 'phone', 'profile_picture', 'bio'),
        }),
    )
    add_fieldsets = UserAdmin.add_fieldsets + (
        ('Custom Profile Info', {
            'fields': ('email', 'role', 'phone', 'profile_picture', 'bio'),
        }),
    )

admin.site.register(User, CustomUserAdmin)
