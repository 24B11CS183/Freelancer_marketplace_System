import copy
from django.template.context import BaseContext

# Patch BaseContext.__copy__ to avoid AttributeError and TypeError on Python 3.14
def patch_base_context_copy(self):
    duplicate = object.__new__(self.__class__)
    duplicate.__dict__.update(self.__dict__)
    duplicate.dicts = self.dicts[:]
    return duplicate

BaseContext.__copy__ = patch_base_context_copy


from django.test import TestCase
from django.contrib.auth import get_user_model
from django.urls import reverse
from datetime import date
from projects.models import Project
from proposals.models import Proposal
from payments.models import Payment, Invoice
from notifications.models import Notification
from admin_dashboard.models import Review

User = get_user_model()

class AdminDashboardTests(TestCase):
    def setUp(self):
        # Create users
        self.superuser = User.objects.create_superuser(
            username="admin_user",
            email="admin@example.com",
            password="adminpassword"
        )
        self.client_user = User.objects.create_user(
            username="client_user",
            email="client@example.com",
            password="clientpassword",
            role="client"
        )
        self.freelancer_user = User.objects.create_user(
            username="freelancer_user",
            email="freelancer@example.com",
            password="freelancerpassword",
            role="freelancer"
        )
        
        # Create projects
        self.project_1 = Project.objects.create(
            client=self.client_user,
            title="Django Backend App",
            description="Build a high performance Django app.",
            budget=3000.00,
            deadline=date(2026, 12, 31),
            status="OPEN",
            is_approved=True
        )
        self.project_2 = Project.objects.create(
            client=self.client_user,
            title="React Website",
            description="Build a premium React front-end.",
            budget=1500.00,
            deadline=date(2026, 11, 30),
            status="HIRED",
            is_approved=False
        )

        # Create proposals
        self.proposal = Proposal.objects.create(
            project=self.project_2,
            freelancer=self.freelancer_user,
            cover_letter="I am expert in React.",
            bid_amount=1500.00,
            estimated_days=7,
            status="ACCEPTED"
        )

        # Create payments & invoices
        self.invoice = Invoice.objects.create(
            invoice_number="INV-000001",
            client=self.client_user,
            freelancer=self.freelancer_user,
            amount=1500.00,
            is_paid=True
        )
        self.payment = Payment.objects.create(
            project=self.project_2,
            client=self.client_user,
            freelancer=self.freelancer_user,
            project_name=self.project_2.title,
            client_name=self.client_user.username,
            freelancer_name=self.freelancer_user.username,
            project_budget=1500.00,
            payment_status="Paid"
        )

        # Create reviews
        self.review = Review.objects.create(
            project=self.project_2,
            reviewer=self.client_user,
            reviewee=self.freelancer_user,
            rating=5,
            comment="Awesome work!",
            is_spam=False
        )

    def test_unauthenticated_cannot_access_admin_dashboard(self):
        url = reverse('admin_dashboard:dashboard')
        response = self.client.get(url)
        self.assertEqual(response.status_code, 302)
        self.assertRedirects(response, reverse('accounts:login'), fetch_redirect_response=False)

    def test_non_staff_cannot_access_admin_dashboard(self):
        # Login as client
        self.client.login(email="client@example.com", password="clientpassword")
        url = reverse('admin_dashboard:dashboard')
        response = self.client.get(url)
        # Should redirect to login (or accounts:login) per AdminRequiredMixin's handle_no_permission
        self.assertEqual(response.status_code, 302)
        self.assertRedirects(response, reverse('accounts:login'), fetch_redirect_response=False)

    def test_superuser_can_access_admin_dashboard(self):
        # Login as superuser
        self.client.login(email="admin@example.com", password="adminpassword")
        url = reverse('admin_dashboard:dashboard')
        response = self.client.get(url)
        self.assertEqual(response.status_code, 200)
        self.assertTemplateUsed(response, 'admin_dashboard/admin_dashboard.html')
        
        # Verify counts in context
        self.assertEqual(response.context['total_users'], 3)
        self.assertEqual(response.context['total_clients'], 2)
        self.assertEqual(response.context['total_freelancers'], 1)
        self.assertEqual(response.context['total_projects'], 2)
        self.assertEqual(response.context['active_projects'], 1)  # React website status='HIRED'
        self.assertEqual(response.context['total_payments'], 1)

    def test_superuser_can_view_users(self):
        self.client.login(email="admin@example.com", password="adminpassword")
        url = reverse('admin_dashboard:users')
        response = self.client.get(url)
        self.assertEqual(response.status_code, 200)
        self.assertTemplateUsed(response, 'admin_dashboard/admin_users.html')
        
        # Test query filtering
        response_q = self.client.get(url, {'q': 'client_user'})
        self.assertEqual(len(response_q.context['users']), 1)
        self.assertEqual(response_q.context['users'][0], self.client_user)

        # Test role filtering
        response_role = self.client.get(url, {'role': 'freelancer'})
        self.assertEqual(len(response_role.context['users']), 1)
        self.assertEqual(response_role.context['users'][0], self.freelancer_user)

    def test_superuser_toggle_user_active(self):
        self.client.login(email="admin@example.com", password="adminpassword")
        url = reverse('admin_dashboard:user_toggle_active', kwargs={'pk': self.client_user.pk})
        
        # Post to toggle active status (currently True -> becomes False)
        response = self.client.post(url)
        self.client_user.refresh_from_db()
        self.assertFalse(self.client_user.is_active)
        self.assertRedirects(response, reverse('admin_dashboard:users'), fetch_redirect_response=False)

        # Check that superuser cannot deactivate themselves
        url_self = reverse('admin_dashboard:user_toggle_active', kwargs={'pk': self.superuser.pk})
        response_self = self.client.post(url_self)
        self.superuser.refresh_from_db()
        self.assertTrue(self.superuser.is_active)
        self.assertRedirects(response_self, reverse('admin_dashboard:users'), fetch_redirect_response=False)

    def test_superuser_delete_user(self):
        self.client.login(email="admin@example.com", password="adminpassword")
        url = reverse('admin_dashboard:user_delete', kwargs={'pk': self.client_user.pk})
        
        # Post to delete user
        response = self.client.post(url)
        self.assertEqual(User.objects.filter(pk=self.client_user.pk).count(), 0)
        self.assertRedirects(response, reverse('admin_dashboard:users'), fetch_redirect_response=False)

        # Cannot delete self
        url_self = reverse('admin_dashboard:user_delete', kwargs={'pk': self.superuser.pk})
        response_self = self.client.post(url_self)
        self.assertEqual(User.objects.filter(pk=self.superuser.pk).count(), 1)
        self.assertRedirects(response_self, reverse('admin_dashboard:users'), fetch_redirect_response=False)

    def test_superuser_view_projects_and_approve(self):
        self.client.login(email="admin@example.com", password="adminpassword")
        url = reverse('admin_dashboard:projects')
        response = self.client.get(url)
        self.assertEqual(response.status_code, 200)
        self.assertTemplateUsed(response, 'admin_dashboard/admin_projects.html')

        # Approve project_2 (currently False -> becomes True)
        url_approve = reverse('admin_dashboard:project_approve', kwargs={'pk': self.project_2.pk})
        response_app = self.client.post(url_approve)
        self.project_2.refresh_from_db()
        self.assertTrue(self.project_2.is_approved)
        self.assertRedirects(response_app, reverse('admin_dashboard:projects'), fetch_redirect_response=False)

    def test_superuser_delete_project(self):
        self.client.login(email="admin@example.com", password="adminpassword")
        url = reverse('admin_dashboard:project_delete', kwargs={'pk': self.project_1.pk})
        response = self.client.post(url)
        self.assertEqual(Project.objects.filter(pk=self.project_1.pk).count(), 0)
        self.assertRedirects(response, reverse('admin_dashboard:projects'), fetch_redirect_response=False)

    def test_superuser_view_payments(self):
        self.client.login(email="admin@example.com", password="adminpassword")
        url = reverse('admin_dashboard:payments')
        response = self.client.get(url)
        self.assertEqual(response.status_code, 200)
        self.assertTemplateUsed(response, 'admin_dashboard/admin_payments.html')
        self.assertEqual(response.context['total_payments_amount'], 1500.00)
        self.assertEqual(response.context['paid_payments_count'], 1)
        self.assertEqual(len(response.context['invoices']), 1)

    def test_superuser_view_reports(self):
        self.client.login(email="admin@example.com", password="adminpassword")
        url = reverse('admin_dashboard:reports')
        response = self.client.get(url)
        self.assertEqual(response.status_code, 200)
        self.assertTemplateUsed(response, 'admin_dashboard/admin_reports.html')
        self.assertEqual(response.context['projects_open'], 1)
        self.assertEqual(response.context['projects_hired'], 1)
        self.assertEqual(response.context['average_rating'], 5.0)
        self.assertEqual(response.context['spam_reviews_count'], 0)

    def test_superuser_toggle_review_spam_and_delete(self):
        self.client.login(email="admin@example.com", password="adminpassword")
        url_toggle = reverse('admin_dashboard:review_toggle_spam', kwargs={'pk': self.review.pk})
        
        # Toggle to spam (currently False -> True)
        response = self.client.post(url_toggle)
        self.review.refresh_from_db()
        self.assertTrue(self.review.is_spam)
        self.assertRedirects(response, reverse('admin_dashboard:reports'), fetch_redirect_response=False)

        # Delete review
        url_delete = reverse('admin_dashboard:review_delete', kwargs={'pk': self.review.pk})
        response_del = self.client.post(url_delete)
        self.assertEqual(Review.objects.filter(pk=self.review.pk).count(), 0)
        self.assertRedirects(response_del, reverse('admin_dashboard:reports'), fetch_redirect_response=False)

    def test_broadcast_notifications(self):
        self.client.login(email="admin@example.com", password="adminpassword")
        url = reverse('admin_dashboard:send_notification')
        
        # Broadcast to all users
        response = self.client.post(url, {
            'target': 'all',
            'title': 'Platform Maintenance',
            'message': 'Scheduled downtime tonight.'
        })
        self.assertRedirects(response, reverse('admin_dashboard:dashboard'), fetch_redirect_response=False)
        self.assertEqual(Notification.objects.filter(title='Platform Maintenance').count(), 3)

        # Broadcast to clients only
        response_client = self.client.post(url, {
            'target': 'clients',
            'title': 'Client Offer',
            'message': '10% discount on next post.'
        })
        self.assertRedirects(response_client, reverse('admin_dashboard:dashboard'), fetch_redirect_response=False)
        self.assertEqual(Notification.objects.filter(title='Client Offer').count(), 2)
