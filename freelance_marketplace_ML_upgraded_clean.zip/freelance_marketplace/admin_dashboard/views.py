from django.shortcuts import render, get_object_or_404, redirect
from django.views import View
from django.views.generic import TemplateView, ListView
from django.contrib.auth import get_user_model
from django.contrib.auth.mixins import UserPassesTestMixin
from django.contrib import messages
from django.db import models
from projects.models import Project
from proposals.models import Proposal
from payments.models import Payment, Invoice
from notifications.models import Notification
from .models import Review
from .forms import BroadcastForm

User = get_user_model()

class AdminRequiredMixin(UserPassesTestMixin):
    """
    Mixin to restrict view access only to authenticated administrators (staff/superusers).
    """
    def test_func(self):
        return self.request.user.is_authenticated and (self.request.user.is_staff or self.request.user.is_superuser)

    def handle_no_permission(self):
        messages.error(self.request, "Access denied. Only administrators can view this page.")
        return redirect('accounts:login')


class AdminDashboardView(AdminRequiredMixin, TemplateView):
    """
    Renders the administrative dashboard overview, displaying system-wide counts.
    """
    template_name = 'admin_dashboard/admin_dashboard.html'

    def get_context_data(self, **kwargs):
        context = super().get_context_data(**kwargs)
        
        # Dashboard Overview Counts
        context['total_users'] = User.objects.count()
        context['total_clients'] = User.objects.filter(role='client').count()
        context['total_freelancers'] = User.objects.filter(role='freelancer').count()
        context['total_projects'] = Project.objects.count()
        context['active_projects'] = Project.objects.filter(status__in=['HIRED', 'IN_PROGRESS']).count()
        context['completed_projects'] = Project.objects.filter(status='COMPLETED').count()
        context['total_proposals'] = Proposal.objects.count()
        context['total_payments'] = Payment.objects.count()
        
        # Add Broadcast Notification form
        context['broadcast_form'] = BroadcastForm()
        
        return context


class AdminUsersView(AdminRequiredMixin, ListView):
    """
    Displays lists of clients and freelancers. Supports searching and role filtering.
    """
    model = User
    template_name = 'admin_dashboard/admin_users.html'
    context_object_name = 'users'
    paginate_by = 10

    def get_queryset(self):
        queryset = User.objects.all().order_by('-created_at')
        
        # Search query
        q = self.request.GET.get('q')
        if q:
            queryset = queryset.filter(
                models.Q(username__icontains=q) | 
                models.Q(email__icontains=q) |
                models.Q(role__icontains=q)
            )
            
        # Role filter
        role = self.request.GET.get('role')
        if role in ['client', 'freelancer']:
            queryset = queryset.filter(role=role)
            
        return queryset

    def get_context_data(self, **kwargs):
        context = super().get_context_data(**kwargs)
        context['q'] = self.request.GET.get('q', '')
        context['role'] = self.request.GET.get('role', '')
        return context


class AdminUserToggleActiveView(AdminRequiredMixin, View):
    """
    Allows administrators to activate or deactivate accounts.
    """
    def post(self, request, pk, *args, **kwargs):
        user = get_object_or_404(User, pk=pk)
        
        # Prevent administrators from deactivating themselves
        if user == request.user:
            messages.error(request, "You cannot deactivate your own account.")
            return redirect('admin_dashboard:users')
            
        user.is_active = not user.is_active
        user.save()
        
        status_text = "activated" if user.is_active else "deactivated"
        messages.success(request, f"User {user.username} was successfully {status_text}.")
        return redirect('admin_dashboard:users')


class AdminUserDeleteView(AdminRequiredMixin, View):
    """
    Allows administrators to permanently delete user accounts.
    """
    def post(self, request, pk, *args, **kwargs):
        user = get_object_or_404(User, pk=pk)
        
        if user == request.user:
            messages.error(request, "You cannot delete your own account.")
            return redirect('admin_dashboard:users')
            
        username = user.username
        user.delete()
        
        messages.success(request, f"User {username} has been permanently deleted.")
        return redirect('admin_dashboard:users')


class AdminProjectsView(AdminRequiredMixin, ListView):
    """
    Lists all platform projects, displaying details, approval flags, and status.
    """
    model = Project
    template_name = 'admin_dashboard/admin_projects.html'
    context_object_name = 'projects'
    paginate_by = 10

    def get_queryset(self):
        queryset = Project.objects.all().order_by('-created_at')
        status = self.request.GET.get('status')
        if status:
            queryset = queryset.filter(status=status)
        return queryset

    def get_context_data(self, **kwargs):
        context = super().get_context_data(**kwargs)
        context['status'] = self.request.GET.get('status', '')
        return context


class AdminProjectApproveView(AdminRequiredMixin, View):
    """
    Toggles the approval status of a project.
    """
    def post(self, request, pk, *args, **kwargs):
        project = get_object_or_404(Project, pk=pk)
        project.is_approved = not project.is_approved
        project.save()
        
        action_text = "approved" if project.is_approved else "unapproved"
        messages.success(request, f"Project '{project.title}' is now {action_text}.")
        return redirect('admin_dashboard:projects')


class AdminProjectDeleteView(AdminRequiredMixin, View):
    """
    Permits administrators to remove listings.
    """
    def post(self, request, pk, *args, **kwargs):
        project = get_object_or_404(Project, pk=pk)
        title = project.title
        project.delete()
        
        messages.success(request, f"Project '{title}' has been removed.")
        return redirect('admin_dashboard:projects')


class AdminPaymentsView(AdminRequiredMixin, ListView):
    """
    Displays payment history, invoices, and transaction summaries.
    """
    model = Payment
    template_name = 'admin_dashboard/admin_payments.html'
    context_object_name = 'payments'
    paginate_by = 10

    def get_queryset(self):
        return Payment.objects.all().order_by('-payment_date')

    def get_context_data(self, **kwargs):
        context = super().get_context_data(**kwargs)
        
        # Payment summaries
        context['total_payments_amount'] = Payment.objects.aggregate(models.Sum('project_budget'))['project_budget__sum'] or 0.00
        context['paid_payments_count'] = Payment.objects.filter(payment_status='Paid').count()
        context['pending_payments_count'] = Payment.objects.filter(payment_status='Pending').count()
        context['invoices'] = Invoice.objects.all().order_by('-created_at')[:10]
        
        return context


class AdminReportsView(AdminRequiredMixin, TemplateView):
    """
    Renders analytics, user registrations, top freelancers/clients, and reviews/rating overview.
    """
    template_name = 'admin_dashboard/admin_reports.html'

    def get_context_data(self, **kwargs):
        context = super().get_context_data(**kwargs)
        
        # Project status statistics
        context['projects_open'] = Project.objects.filter(status='OPEN').count()
        context['projects_hired'] = Project.objects.filter(status='HIRED').count()
        context['projects_progress'] = Project.objects.filter(status='IN_PROGRESS').count()
        context['projects_completed'] = Project.objects.filter(status='COMPLETED').count()
        
        # Top 5 Freelancers by proposals
        context['active_freelancers'] = User.objects.filter(role='freelancer').annotate(
            proposal_count=models.Count('proposals')
        ).order_by('-proposal_count')[:5]

        # Top 5 Clients by projects posted
        context['active_clients'] = User.objects.filter(role='client').annotate(
            project_count=models.Count('posted_projects')
        ).order_by('-project_count')[:5]

        # Ratings & Reviews
        context['reviews'] = Review.objects.all().order_by('-created_at')
        context['spam_reviews_count'] = Review.objects.filter(is_spam=True).count()
        context['average_rating'] = Review.objects.aggregate(models.Avg('rating'))['rating__avg'] or 5.0

        return context


class AdminSendNotificationView(AdminRequiredMixin, View):
    """
    Broadcasts message notifications to platform users.
    """
    def post(self, request, *args, **kwargs):
        form = BroadcastForm(request.POST)
        if form.is_valid():
            target = form.cleaned_data['target']
            title = form.cleaned_data['title']
            message = form.cleaned_data['message']
            
            # Query targeted users
            if target == 'all':
                users = User.objects.all()
            elif target == 'clients':
                users = User.objects.filter(role='client')
            elif target == 'freelancers':
                users = User.objects.filter(role='freelancer')
            else:
                users = User.objects.none()
                
            # Create notifications
            notifications = [
                Notification(user=u, title=title, message=message) for u in users
            ]
            Notification.objects.bulk_create(notifications)
            
            messages.success(request, f"Notification broadcasted successfully to {users.count()} users.")
        else:
            messages.error(request, "Failed to broadcast message. Please check the inputs.")
            
        return redirect('admin_dashboard:dashboard')


class AdminReviewToggleSpamView(AdminRequiredMixin, View):
    """
    Allows administrators to flag or unflag a review as spam.
    """
    def post(self, request, pk, *args, **kwargs):
        review = get_object_or_404(Review, pk=pk)
        review.is_spam = not review.is_spam
        review.save()
        
        status_text = "marked as spam" if review.is_spam else "unflagged"
        messages.success(request, f"Review has been {status_text}.")
        return redirect('admin_dashboard:reports')


class AdminReviewDeleteView(AdminRequiredMixin, View):
    """
    Permanently deletes spam or abusive reviews.
    """
    def post(self, request, pk, *args, **kwargs):
        review = get_object_or_404(Review, pk=pk)
        review.delete()
        
        messages.success(request, "Review has been permanently removed.")
        return redirect('admin_dashboard:reports')
