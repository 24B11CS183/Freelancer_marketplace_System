from django.urls import path
from . import views

app_name = 'admin_dashboard'

urlpatterns = [
    path('', views.AdminDashboardView.as_view(), name='dashboard'),
    path('users/', views.AdminUsersView.as_view(), name='users'),
    path('users/<uuid:pk>/toggle-active/', views.AdminUserToggleActiveView.as_view(), name='user_toggle_active'),
    path('users/<uuid:pk>/delete/', views.AdminUserDeleteView.as_view(), name='user_delete'),
    path('projects/', views.AdminProjectsView.as_view(), name='projects'),
    path('projects/<uuid:pk>/approve/', views.AdminProjectApproveView.as_view(), name='project_approve'),
    path('projects/<uuid:pk>/delete/', views.AdminProjectDeleteView.as_view(), name='project_delete'),
    path('payments/', views.AdminPaymentsView.as_view(), name='payments'),
    path('reports/', views.AdminReportsView.as_view(), name='reports'),
    path('broadcast/', views.AdminSendNotificationView.as_view(), name='send_notification'),
    path('reviews/<uuid:pk>/toggle-spam/', views.AdminReviewToggleSpamView.as_view(), name='review_toggle_spam'),
    path('reviews/<uuid:pk>/delete/', views.AdminReviewDeleteView.as_view(), name='review_delete'),
]
