from django import forms

class BroadcastForm(forms.Form):
    """
    Form used by administrators to broadcast alerts/messages to users.
    """
    TARGET_CHOICES = (
        ('all', 'All Users'),
        ('clients', 'All Clients'),
        ('freelancers', 'All Freelancers'),
    )
    target = forms.ChoiceField(
        choices=TARGET_CHOICES, 
        widget=forms.Select(attrs={'class': 'form-select'})
    )
    title = forms.CharField(
        max_length=255, 
        widget=forms.TextInput(attrs={'class': 'form-control', 'placeholder': 'Notification Title'})
    )
    message = forms.CharField(
        widget=forms.Textarea(attrs={'class': 'form-control', 'placeholder': 'Write message details here...', 'rows': 4})
    )
