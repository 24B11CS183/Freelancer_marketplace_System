from django import forms
from .models import Project

class ProjectForm(forms.ModelForm):
    """
    Form for posting and updating project details, including skills required.
    """
    class Meta:
        model = Project
        fields = ('title', 'category', 'description', 'budget', 'deadline', 'skills_required')
        widgets = {
            'title': forms.TextInput(attrs={'placeholder': 'e.g. Build a Responsive Django Website'}),
            'category': forms.TextInput(attrs={'placeholder': 'e.g. Software Development'}),
            'description': forms.Textarea(attrs={
                'rows': 5, 
                'placeholder': 'Outline the task description, deliverables, required stack, and instructions...'
            }),
            'budget': forms.NumberInput(attrs={'step': '1.00', 'placeholder': '250.00'}),
            'deadline': forms.DateInput(attrs={'type': 'date'}),
            'skills_required': forms.TextInput(attrs={'placeholder': 'e.g. Python, Django, React (comma separated)'}),
        }

    def clean_budget(self):
        budget = self.cleaned_data.get('budget')
        if budget is not None and budget <= 0:
            raise forms.ValidationError("Budget must be a positive number.")
        return budget


from .models import ProjectSubmission

class ProjectSubmissionForm(forms.ModelForm):
    """
    Form for freelancers to deliver completed project work.
    """
    class Meta:
        model = ProjectSubmission
        fields = ('zip_file', 'github_link', 'demo_link', 'notes')
        widgets = {
            'zip_file': forms.FileInput(attrs={'accept': '.zip', 'class': 'form-control'}),
            'github_link': forms.URLInput(attrs={'placeholder': 'e.g. https://github.com/username/project'}),
            'demo_link': forms.URLInput(attrs={'placeholder': 'e.g. https://my-demo-link.com'}),
            'notes': forms.Textarea(attrs={
                'rows': 4,
                'placeholder': 'Provide any notes about your completion, credentials, or instructions...'
            }),
        }

    def clean_zip_file(self):
        zip_file = self.cleaned_data.get('zip_file')
        if zip_file:
            if not zip_file.name.endswith('.zip'):
                raise forms.ValidationError("Only ZIP files are allowed.")
        return zip_file
