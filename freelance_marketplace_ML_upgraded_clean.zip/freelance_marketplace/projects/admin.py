from django.contrib import admin
from .models import Project

class ProjectAdmin(admin.ModelAdmin):
    """
    Admin configuration for the Project model.
    Provides complete control over project listings, category fields, and statuses.
    """
    list_display = ['title', 'client', 'budget', 'category', 'status', 'deadline', 'created_at']
    search_fields = ['title', 'description', 'client__email', 'client__username', 'category']
    list_filter = ['status', 'category', 'deadline', 'created_at']

admin.site.register(Project, ProjectAdmin)
