from django.urls import path
from . import views

app_name = 'projects'

urlpatterns = [
    path('', views.ProjectListView.as_view(), name='project_list'),
    path('<uuid:pk>/', views.ProjectDetailView.as_view(), name='project_detail'),
    path('<uuid:pk>/edit/', views.ProjectUpdateView.as_view(), name='project_edit'),
    path('<uuid:pk>/delete/', views.ProjectDeleteView.as_view(), name='project_delete'),
    path('<uuid:project_id>/submit-work/', views.SubmitWorkView.as_view(), name='submit_work'),
    path('submission/<uuid:pk>/approve/', views.ApproveSubmissionView.as_view(), name='approve_submission'),
    path('submission/<uuid:pk>/reject/', views.RejectSubmissionView.as_view(), name='reject_submission'),
    path('<uuid:project_id>/review/', views.CreateReviewView.as_view(), name='create_review'),
]
