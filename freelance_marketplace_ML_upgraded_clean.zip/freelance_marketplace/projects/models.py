import uuid
from django.db import models
from django.conf import settings

class Project(models.Model):
    """
    Model representing job/project listings posted by clients.
    """
    STATUS_CHOICES = (
        ('OPEN', 'Open'),
        ('HIRED', 'Hired'),
        ('IN_PROGRESS', 'In Progress'),
        ('COMPLETED', 'Completed'),
        ('CANCELLED', 'Cancelled'),
    )

    # UUID primary key
    id = models.UUIDField(primary_key=True, default=uuid.uuid4, editable=False)
    
    # Relationships
    client = models.ForeignKey(
        settings.AUTH_USER_MODEL, 
        on_delete=models.CASCADE, 
        related_name='posted_projects'
    )
    
    # Project attributes
    title = models.CharField(max_length=255)
    description = models.TextField()
    budget = models.DecimalField(max_digits=10, decimal_places=2)
    category = models.CharField(
        max_length=100, 
        help_text="e.g. Design, Web Development, Writing, Marketing",
        blank=True, 
        null=True
    )
    deadline = models.DateField()
    status = models.CharField(max_length=20, choices=STATUS_CHOICES, default='OPEN')
    skills_required = models.TextField(
        blank=True, 
        null=True, 
        help_text="Comma-separated skills list. e.g. Python, Django, HTML5"
    )
    created_at = models.DateTimeField(auto_now_add=True)
    updated_at = models.DateTimeField(auto_now=True)
    is_approved = models.BooleanField(default=True)

    def __str__(self):
        return f"{self.title} - {self.client.username} ({self.get_status_display()})"

    @property
    def latest_submission(self):
        return self.submissions.order_by('-submitted_at').first()

    @property
    def is_paid(self):
        if hasattr(self, '_is_paid'):
            return self._is_paid
        from payments.models import Payment
        return Payment.objects.filter(project=self, payment_status='Paid').exists()

    @is_paid.setter
    def is_paid(self, value):
        self._is_paid = value




class ProjectSubmission(models.Model):
    """
    Model representing freelancer's work submissions/deliveries.
    """
    STATUS_CHOICES = (
        ('PENDING', 'Pending'),
        ('APPROVED', 'Approved'),
        ('REJECTED', 'Rejected'),
    )

    id = models.UUIDField(primary_key=True, default=uuid.uuid4, editable=False)
    project = models.ForeignKey(Project, on_delete=models.CASCADE, related_name='submissions')
    freelancer = models.ForeignKey(
        settings.AUTH_USER_MODEL, 
        on_delete=models.CASCADE, 
        related_name='submissions'
    )
    zip_file = models.FileField(upload_to='project_submissions/')
    github_link = models.URLField(max_length=500, blank=True, null=True)
    demo_link = models.URLField(max_length=500, blank=True, null=True)
    notes = models.TextField()
    submitted_at = models.DateTimeField(auto_now_add=True)
    status = models.CharField(max_length=20, choices=STATUS_CHOICES, default='PENDING')

    def __str__(self):
        return f"Submission for {self.project.title} by {self.freelancer.username} - {self.get_status_display()}"
