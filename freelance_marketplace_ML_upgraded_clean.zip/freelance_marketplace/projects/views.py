from django.shortcuts import render, get_object_or_404, redirect
from django.urls import reverse_lazy
from django.views.generic import ListView, DetailView, UpdateView, DeleteView
from django.contrib.auth.mixins import LoginRequiredMixin
from core.mixins import ClientRequiredMixin
from django.contrib import messages
from django.db.models import Q
from .models import Project
from .forms import ProjectForm
from proposals.models import Proposal

class ProjectListView(LoginRequiredMixin, ListView):
    """
    Renders the public Project Marketplace listing.
    Supports text searches (matching title/description), category and budget filtering,
    and returns a paginated list of open projects.
    """
    model = Project
    template_name = 'projects/project_list.html'
    context_object_name = 'projects'
    paginate_by = 6

    def get_queryset(self):
        # Only show open listings by default in the search market
        queryset = Project.objects.filter(status='OPEN')
        
        # Text query matching title or description
        search_query = self.request.GET.get('q')
        if search_query:
            queryset = queryset.filter(
                Q(title__icontains=search_query) | 
                Q(description__icontains=search_query)
            )
            
        # Category selection filter
        category_query = self.request.GET.get('category')
        if category_query:
            queryset = queryset.filter(category__iexact=category_query)
            
        # Financial budget constraints
        min_budget = self.request.GET.get('min_budget')
        max_budget = self.request.GET.get('max_budget')
        if min_budget:
            queryset = queryset.filter(budget__gte=min_budget)
        if max_budget:
            queryset = queryset.filter(budget__lte=max_budget)
            
        return queryset.order_by('-created_at')

    def get_context_data(self, **kwargs):
        context = super().get_context_data(**kwargs)
        # Fetch unique categories to populate dropdown filter select
        context['categories'] = Project.objects.values_list('category', flat=True)\
            .distinct().exclude(category__isnull=True).exclude(category='')
        return context


class ProjectDetailView(LoginRequiredMixin, DetailView):
    """
    Renders detail views for specific projects.
    Shows all proposals if requested by the client creator;
    otherwise, shows only the requesting freelancer's proposal if they bid on it.
    """
    model = Project
    template_name = 'projects/project_detail.html'
    context_object_name = 'project'

    def get_context_data(self, **kwargs):
        context = super().get_context_data(**kwargs)
        project = self.get_object()
        
        # Display submitted proposals differently depending on identity
        if self.request.user == project.client:
            context['proposals'] = Proposal.objects.filter(project=project).select_related('freelancer')
        else:
            context['freelancer_proposal'] = Proposal.objects.filter(
                project=project, 
                freelancer=self.request.user
            ).first()
            
        # Fetch project reviews
        context['reviews'] = project.reviews.all().select_related('reviewer')
        context['has_reviewed'] = project.reviews.filter(reviewer=self.request.user).exists()
        
        # Identify the hired freelancer for this project
        accepted_proposal = project.proposals.filter(status='ACCEPTED').first()
        context['hired_freelancer'] = accepted_proposal.freelancer if accepted_proposal else None
        
        return context


class ProjectUpdateView(ClientRequiredMixin, UpdateView):
    """
    Enables clients to update details on their existing project listings.
    """
    model = Project
    form_class = ProjectForm
    template_name = 'projects/project_edit.html'
    
    def get_queryset(self):
        # Verify ownership
        return Project.objects.filter(client=self.request.user)

    def get_success_url(self):
        return reverse_lazy('clients:my_projects')

    def form_valid(self, form):
        messages.success(self.request, "Project listing updated successfully.")
        return super().form_valid(form)


class ProjectDeleteView(ClientRequiredMixin, DeleteView):
    """
    Allows clients to delete their project listing.
    """
    model = Project
    template_name = 'projects/project_confirm_delete.html'
    success_url = reverse_lazy('clients:my_projects')

    def get_queryset(self):
        # Verify ownership
        return Project.objects.filter(client=self.request.user)

    def delete(self, request, *args, **kwargs):
        messages.success(self.request, "Project listing has been removed.")
        return super().delete(request, *args, **kwargs)


from django.views import View
from django.views.generic import CreateView
from .models import ProjectSubmission
from .forms import ProjectSubmissionForm

class SubmitWorkView(LoginRequiredMixin, CreateView):
    """
    Allows the hired freelancer to submit their work (ZIP file, demo link, github link, notes).
    """
    model = ProjectSubmission
    form_class = ProjectSubmissionForm
    template_name = 'projects/submit_work.html'

    def dispatch(self, request, *args, **kwargs):
        self.project = get_object_or_404(Project, pk=self.kwargs.get('project_id'))
        
        # Verify the user is the hired freelancer
        accepted_proposal = self.project.proposals.filter(status='ACCEPTED').first()
        if not accepted_proposal or accepted_proposal.freelancer != request.user:
            messages.error(request, "You are not authorized to submit work for this project.")
            return redirect('freelancers:dashboard')
            
        # Ensure project is HIRED or IN_PROGRESS
        if self.project.status not in ['HIRED', 'IN_PROGRESS']:
            messages.error(request, "Work cannot be submitted for this project in its current status.")
            return redirect('freelancers:dashboard')
            
        return super().dispatch(request, *args, **kwargs)

    def form_valid(self, form):
        form.instance.project = self.project
        form.instance.freelancer = self.request.user
        form.instance.status = 'PENDING'
        
        # Save submission
        form.save()
        
        messages.success(self.request, "Your project work has been submitted successfully!")
        return redirect('freelancers:dashboard')

    def get_context_data(self, **kwargs):
        context = super().get_context_data(**kwargs)
        context['project'] = self.project
        return context


class ApproveSubmissionView(LoginRequiredMixin, View):
    """
    Allows clients to approve a freelancer's submission.
    Marks project as completed.
    """
    def post(self, request, pk, *args, **kwargs):
        submission = get_object_or_404(ProjectSubmission, pk=pk)
        
        # Verify client ownership of the project
        if submission.project.client != request.user:
            messages.error(request, "Unauthorized action.")
            return redirect('clients:dashboard')
            
        submission.status = 'APPROVED'
        submission.save()
        
        # Complete the project
        project = submission.project
        project.status = 'COMPLETED'
        project.save()
        
        messages.success(request, f"Submission for '{project.title}' has been approved successfully! Project marked as completed.")
        return redirect('clients:dashboard')


class RejectSubmissionView(LoginRequiredMixin, View):
    """
    Allows clients to reject a freelancer's submission, allowing resubmission.
    """
    def post(self, request, pk, *args, **kwargs):
        submission = get_object_or_404(ProjectSubmission, pk=pk)
        
        # Verify client ownership of the project
        if submission.project.client != request.user:
            messages.error(request, "Unauthorized action.")
            return redirect('clients:dashboard')
            
        submission.status = 'REJECTED'
        submission.save()
        
        messages.warning(request, f"Submission for '{submission.project.title}' has been rejected.")
        return redirect('clients:dashboard')


from admin_dashboard.models import Review

class CreateReviewView(LoginRequiredMixin, View):
    """
    Handles submitting a rating and review for a completed project.
    """
    def post(self, request, project_id, *args, **kwargs):
        project = get_object_or_404(Project, pk=project_id)
        
        # Verify project is COMPLETED
        if project.status != 'COMPLETED':
            messages.error(request, "You can only review completed projects.")
            return redirect('projects:project_detail', pk=project.pk)
            
        # Identify reviewer and reviewee
        accepted_proposal = project.proposals.filter(status='ACCEPTED').first()
        if not accepted_proposal:
            messages.error(request, "No freelancer was hired for this project.")
            return redirect('projects:project_detail', pk=project.pk)
            
        freelancer = accepted_proposal.freelancer
        
        if request.user == project.client:
            reviewer = project.client
            reviewee = freelancer
        elif request.user == freelancer:
            reviewer = freelancer
            reviewee = project.client
        else:
            messages.error(request, "You are not authorized to review this project.")
            return redirect('projects:project_detail', pk=project.pk)
            
        # Prevent double reviews from the same user on the same project
        if Review.objects.filter(project=project, reviewer=reviewer).exists():
            messages.warning(request, "You have already submitted a review for this project.")
            return redirect('projects:project_detail', pk=project.pk)
            
        rating = request.POST.get('rating')
        comment = request.POST.get('comment')
        
        try:
            rating_val = int(rating)
            if rating_val < 1 or rating_val > 5:
                raise ValueError()
        except (TypeError, ValueError):
            messages.error(request, "Invalid rating value. Must be between 1 and 5.")
            return redirect('projects:project_detail', pk=project.pk)
            
        # Create review
        Review.objects.create(
            project=project,
            reviewer=reviewer,
            reviewee=reviewee,
            rating=rating_val,
            comment=comment
        )
        
        # Send notification to reviewee
        from notifications.utils import create_notification
        create_notification(
            user=reviewee,
            title="New Review Received",
            message=f"You received a {rating_val}-star review from {reviewer.username} for the project '{project.title}'."
        )
        
        messages.success(request, "Your review has been submitted successfully!")
        return redirect('projects:project_detail', pk=project.pk)
