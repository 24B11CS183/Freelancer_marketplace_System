from django.test import TestCase, RequestFactory
from django.contrib.auth import get_user_model
from django.urls import reverse
from django.core.files.uploadedfile import SimpleUploadedFile
from django.core.exceptions import PermissionDenied
from django.contrib.messages.storage.base import BaseStorage
from datetime import date
from projects.models import Project, ProjectSubmission
from proposals.models import Proposal
from projects.views import SubmitWorkView, ApproveSubmissionView, RejectSubmissionView

User = get_user_model()

class DummyMessageStorage(BaseStorage):
    """
    Dummy messages storage backend for RequestFactory tests to bypass session middleware dependency.
    """
    def _get(self):
        return [], True

    def _store(self, messages, response, *args, **kwargs):
        return []

class ProjectDeliveryTests(TestCase):
    def setUp(self):
        self.factory = RequestFactory()
        self.client_user = User.objects.create_user(
            username="client_user",
            email="client@example.com",
            password="password123",
            role="client"
        )
        self.freelancer_user = User.objects.create_user(
            username="freelancer_user",
            email="freelancer@example.com",
            password="password123",
            role="freelancer"
        )
        self.other_user = User.objects.create_user(
            username="other_user",
            email="other@example.com",
            password="password123",
            role="freelancer"
        )
        self.project = Project.objects.create(
            client=self.client_user,
            title="Design System Project",
            description="Build a high quality design system.",
            budget=2000.00,
            deadline=date(2026, 12, 31),
            status="HIRED"
        )
        self.proposal = Proposal.objects.create(
            project=self.project,
            freelancer=self.freelancer_user,
            cover_letter="I can deliver this.",
            bid_amount=2000.00,
            estimated_days=10,
            status="ACCEPTED"
        )

    def test_hired_freelancer_can_access_submit_work(self):
        request = self.factory.get(reverse('projects:submit_work', kwargs={'project_id': self.project.pk}))
        request.user = self.freelancer_user
        
        view = SubmitWorkView()
        view.request = request
        view.kwargs = {'project_id': self.project.pk}
        
        response = view.dispatch(request, project_id=self.project.pk)
        self.assertEqual(response.status_code, 200)

    def test_unauthorized_user_cannot_access_submit_work(self):
        request = self.factory.get(reverse('projects:submit_work', kwargs={'project_id': self.project.pk}))
        request.user = self.other_user
        setattr(request, '_messages', DummyMessageStorage(request))
        
        view = SubmitWorkView()
        view.request = request
        view.kwargs = {'project_id': self.project.pk}
        
        response = view.dispatch(request, project_id=self.project.pk)
        self.assertEqual(response.status_code, 302) # Redirects to freelancer dashboard

    def test_freelancer_submit_work_valid_zip(self):
        zip_file = SimpleUploadedFile("delivery.zip", b"dummy contents", content_type="application/zip")
        request = self.factory.post(
            reverse('projects:submit_work', kwargs={'project_id': self.project.pk}),
            {
                'zip_file': zip_file,
                'github_link': 'https://github.com/freelancer/delivery',
                'demo_link': 'https://demo.example.com',
                'notes': 'All tasks completed successfully!'
            }
        )
        request.user = self.freelancer_user
        setattr(request, '_messages', DummyMessageStorage(request))
        
        view = SubmitWorkView()
        view.request = request
        view.kwargs = {'project_id': self.project.pk}
        
        response = view.dispatch(request, project_id=self.project.pk)
        self.assertEqual(response.status_code, 302)
        self.assertEqual(ProjectSubmission.objects.count(), 1)
        sub = ProjectSubmission.objects.first()
        self.assertEqual(sub.status, 'PENDING')
        self.assertEqual(sub.notes, 'All tasks completed successfully!')

    def test_freelancer_submit_work_invalid_extension(self):
        txt_file = SimpleUploadedFile("delivery.txt", b"dummy contents", content_type="text/plain")
        request = self.factory.post(
            reverse('projects:submit_work', kwargs={'project_id': self.project.pk}),
            {
                'zip_file': txt_file,
                'notes': 'Here is text file'
            }
        )
        request.user = self.freelancer_user
        setattr(request, '_messages', DummyMessageStorage(request))
        
        view = SubmitWorkView()
        view.request = request
        view.kwargs = {'project_id': self.project.pk}
        
        response = view.dispatch(request, project_id=self.project.pk)
        self.assertEqual(response.status_code, 200) # Re-renders form with validation error
        self.assertEqual(ProjectSubmission.objects.count(), 0)

    def test_client_approve_submission(self):
        sub = ProjectSubmission.objects.create(
            project=self.project,
            freelancer=self.freelancer_user,
            zip_file=SimpleUploadedFile("delivery.zip", b"contents"),
            notes="Hired freelancer delivery.",
            status="PENDING"
        )
        request = self.factory.post(reverse('projects:approve_submission', kwargs={'pk': sub.pk}))
        request.user = self.client_user
        setattr(request, '_messages', DummyMessageStorage(request))
        
        view = ApproveSubmissionView()
        view.request = request
        view.kwargs = {'pk': sub.pk}
        
        response = view.dispatch(request, pk=sub.pk)
        self.assertEqual(response.status_code, 302)
        sub.refresh_from_db()
        self.assertEqual(sub.status, 'APPROVED')
        self.project.refresh_from_db()
        self.assertEqual(self.project.status, 'COMPLETED')

    def test_client_reject_submission(self):
        sub = ProjectSubmission.objects.create(
            project=self.project,
            freelancer=self.freelancer_user,
            zip_file=SimpleUploadedFile("delivery.zip", b"contents"),
            notes="Hired freelancer delivery.",
            status="PENDING"
        )
        request = self.factory.post(reverse('projects:reject_submission', kwargs={'pk': sub.pk}))
        request.user = self.client_user
        setattr(request, '_messages', DummyMessageStorage(request))
        
        view = RejectSubmissionView()
        view.request = request
        view.kwargs = {'pk': sub.pk}
        
        response = view.dispatch(request, pk=sub.pk)
        self.assertEqual(response.status_code, 302)
        sub.refresh_from_db()
        self.assertEqual(sub.status, 'REJECTED')
        self.project.refresh_from_db()
        self.assertEqual(self.project.status, 'HIRED')
