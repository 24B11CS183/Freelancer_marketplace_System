from django.urls import path
from . import views

app_name = 'notifications'

urlpatterns = [
    path('', views.NotificationListView.as_view(), name='notification_list'),
    path('mark-read/<uuid:pk>/', views.MarkNotificationAsReadView.as_view(), name='mark_read'),
    path('mark-all-read/', views.MarkAllNotificationsAsReadView.as_view(), name='mark_all_read'),
]
