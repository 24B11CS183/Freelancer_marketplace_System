from django.db.models.signals import post_save
from django.dispatch import receiver
from proposals.models import Proposal
from payments.models import Invoice, Payment
from projects.models import ProjectSubmission
from .models import Notification
from .utils import create_notification

@receiver(post_save, sender=Proposal)
def proposal_notification(sender, instance, created, **kwargs):
    """
    Signal handler to generate notifications when proposals are submitted, accepted, or rejected.
    """
    if created:
        # Proposal created -> notify the project client
        project = instance.project
        create_notification(
            user=project.client,
            title="New Proposal Received",
            message=f"Freelancer '{instance.freelancer.username}' submitted a proposal for your project '{project.title}'."
        )
    else:
        # Proposal updated -> notify the freelancer if status transitioned to ACCEPTED or REJECTED
        if instance.status == 'ACCEPTED':
            # Check if notification was already sent to avoid duplicates on multi-saves
            notified = Notification.objects.filter(
                user=instance.freelancer,
                title="Proposal Accepted!",
                message__contains=instance.project.title
            ).exists()
            if not notified:
                create_notification(
                    user=instance.freelancer,
                    title="Proposal Accepted!",
                    message=f"Your proposal for the project '{instance.project.title}' has been accepted!"
                )
        elif instance.status == 'REJECTED':
            notified = Notification.objects.filter(
                user=instance.freelancer,
                title="Proposal Declined",
                message__contains=instance.project.title
            ).exists()
            if not notified:
                create_notification(
                    user=instance.freelancer,
                    title="Proposal Declined",
                    message=f"Your proposal for the project '{instance.project.title}' was declined."
                )

@receiver(post_save, sender=Invoice)
def invoice_notification(sender, instance, created, **kwargs):
    """
    Signal handler to generate notifications when billing invoices are created.
    """
    if created:
        # Notify both the client (payer) and the freelancer (payee)
        create_notification(
            user=instance.client,
            title="Invoice Generated",
            message=f"An invoice ({instance.invoice_number}) for ₹{instance.amount} has been generated and requires payment."
        )
        create_notification(
            user=instance.freelancer,
            title="Invoice Sent",
            message=f"Invoice ({instance.invoice_number}) for ₹{instance.amount} has been sent to the client."
        )


@receiver(post_save, sender=Payment)
def payment_notification(sender, instance, created, **kwargs):
    """
    Signal handler to generate notifications when payments are marked as Paid.
    Notifies both the client (confirmation) and the freelancer (funds released).
    """
    if not created and instance.payment_status == 'Paid':
        # Only notify when status transitions to Paid (not on initial creation)
        notified = Notification.objects.filter(
            user=instance.freelancer,
            title="Payment Received!",
            message__contains=instance.project_name
        ).exists()
        if not notified:
            if instance.freelancer:
                create_notification(
                    user=instance.freelancer,
                    title="Payment Received!",
                    message=f"Payment of ₹{instance.project_budget} for project '{instance.project_name}' has been released to your account."
                )
            if instance.client:
                create_notification(
                    user=instance.client,
                    title="Payment Confirmed",
                    message=f"Your payment of ₹{instance.project_budget} for project '{instance.project_name}' has been processed successfully."
                )


@receiver(post_save, sender=ProjectSubmission)
def submission_notification(sender, instance, created, **kwargs):
    """
    Signal handler to generate notifications when work is submitted, approved, or rejected.
    """
    if created:
        # Notify the client that work has been delivered
        create_notification(
            user=instance.project.client,
            title="Work Submitted",
            message=f"Freelancer '{instance.freelancer.username}' has submitted work for your project '{instance.project.title}'. Please review the delivery."
        )
    else:
        if instance.status == 'APPROVED':
            notified = Notification.objects.filter(
                user=instance.freelancer,
                title="Submission Approved!",
                message__contains=instance.project.title
            ).exists()
            if not notified:
                create_notification(
                    user=instance.freelancer,
                    title="Submission Approved!",
                    message=f"Your submission for project '{instance.project.title}' has been approved! The project is now marked as completed."
                )
        elif instance.status == 'REJECTED':
            notified = Notification.objects.filter(
                user=instance.freelancer,
                title="Submission Rejected",
                message__contains=instance.project.title
            ).exists()
            if not notified:
                create_notification(
                    user=instance.freelancer,
                    title="Submission Rejected",
                    message=f"Your submission for project '{instance.project.title}' was rejected. You may resubmit your work."
                )

