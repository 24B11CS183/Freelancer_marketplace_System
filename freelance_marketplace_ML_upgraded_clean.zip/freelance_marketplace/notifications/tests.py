from django.test import TestCase, RequestFactory
from django.contrib.auth import get_user_model
from projects.models import Project
from proposals.models import Proposal
from payments.models import Invoice
from notifications.models import Notification
from notifications.context_processors import notification_context

User = get_user_model()

class NotificationTests(TestCase):
    def setUp(self):
        # Create users
        self.client_user = User.objects.create_user(
            username="client_user",
            email="client@example.com",
            password="password123",
            role="client"
        )
        self.freelancer_user = User.objects.create_user(
            username="freelancer_user",
            email="freelancer@example.com",
            password="password123",
            role="freelancer"
        )
        # Create project
        from datetime import date
        self.project = Project.objects.create(
            client=self.client_user,
            title="Test Web App",
            description="Build a high performance web application.",
            budget=1500.00,
            category="DEVELOPMENT",
            skills_required="Django, Python",
            deadline=date(2026, 12, 31)
        )
        self.factory = RequestFactory()

    def test_proposal_submission_triggers_notification(self):
        # Submitting proposal should notify the project owner (client)
        proposal = Proposal.objects.create(
            project=self.project,
            freelancer=self.freelancer_user,
            cover_letter="I can do this easily.",
            bid_amount=1200.00,
            estimated_days=10
        )
        
        # Verify notification created for client
        notifications = Notification.objects.filter(user=self.client_user)
        self.assertEqual(notifications.count(), 1)
        notification = notifications.first()
        self.assertEqual(notification.title, "New Proposal Received")
        self.assertIn("freelancer_user", notification.message)
        self.assertIn(self.project.title, notification.message)

    def test_proposal_acceptance_triggers_notification_and_invoice(self):
        proposal = Proposal.objects.create(
            project=self.project,
            freelancer=self.freelancer_user,
            cover_letter="I can do this easily.",
            bid_amount=1200.00,
            estimated_days=10
        )
        
        # Clear previous notification for a clean assert
        Notification.objects.all().delete()
        
        # Accept proposal
        proposal.status = "ACCEPTED"
        proposal.save()
        
        # Accepting a proposal changes project status and creates an Invoice in the view.
        # But wait! In views.py, Invoice creation is done manually:
        # Invoice.objects.create(invoice_number=..., client=..., freelancer=..., amount=...)
        # Let's verify if Proposal update triggers "Proposal Accepted!" notification.
        freelancer_notifications = Notification.objects.filter(user=self.freelancer_user, title="Proposal Accepted!")
        self.assertEqual(freelancer_notifications.count(), 1)
        self.assertIn(self.project.title, freelancer_notifications.first().message)

    def test_proposal_rejection_triggers_notification(self):
        proposal = Proposal.objects.create(
            project=self.project,
            freelancer=self.freelancer_user,
            cover_letter="I can do this easily.",
            bid_amount=1200.00,
            estimated_days=10
        )
        
        # Clear previous notification
        Notification.objects.all().delete()
        
        # Reject proposal
        proposal.status = "REJECTED"
        proposal.save()
        
        freelancer_notifications = Notification.objects.filter(user=self.freelancer_user, title="Proposal Declined")
        self.assertEqual(freelancer_notifications.count(), 1)
        self.assertIn(self.project.title, freelancer_notifications.first().message)

    def test_invoice_creation_triggers_notification(self):
        # Create an Invoice manually
        invoice = Invoice.objects.create(
            invoice_number="INV-2026-0001",
            client=self.client_user,
            freelancer=self.freelancer_user,
            amount=1200.00
        )
        
        # Verify notification created for client
        client_notifications = Notification.objects.filter(user=self.client_user, title="Invoice Generated")
        self.assertEqual(client_notifications.count(), 1)
        self.assertIn("INV-2026-0001", client_notifications.first().message)
        
        # Verify notification created for freelancer
        freelancer_notifications = Notification.objects.filter(user=self.freelancer_user, title="Invoice Sent")
        self.assertEqual(freelancer_notifications.count(), 1)
        self.assertIn("INV-2026-0001", freelancer_notifications.first().message)

    def test_notification_context_processor(self):
        # Create 2 unread notifications for freelancer
        Notification.objects.create(user=self.freelancer_user, title="Alert 1", message="Msg 1")
        Notification.objects.create(user=self.freelancer_user, title="Alert 2", message="Msg 2")
        
        # Mock request with authenticated freelancer
        request = self.factory.get("/")
        request.user = self.freelancer_user
        
        context = notification_context(request)
        self.assertEqual(context["unread_notifications_count"], 2)
        self.assertEqual(context["unread_messages_count"], 0)
        
        # Mock request with unauthenticated user
        from django.contrib.auth.models import AnonymousUser
        request.user = AnonymousUser()
        context = notification_context(request)
        self.assertEqual(context["unread_notifications_count"], 0)
        self.assertEqual(context["unread_messages_count"], 0)
