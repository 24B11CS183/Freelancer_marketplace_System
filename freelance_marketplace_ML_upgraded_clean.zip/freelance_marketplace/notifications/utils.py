from .models import Notification

def create_notification(user, title, message):
    """
    Utility function to create and save a new notification for a specific user.
    """
    return Notification.objects.create(
        user=user,
        title=title,
        message=message
    )


def mark_as_read(notification_id):
    """
    Utility function to mark a specific notification as read.
    Returns True if successfully marked, otherwise False.
    """
    try:
        notification = Notification.objects.get(id=notification_id)
        notification.is_read = True
        notification.save()
        return True
    except Notification.DoesNotExist:
        return False


def mark_all_user_notifications_as_read(user):
    """
    Helper function to mark all unread notifications for a user as read.
    """
    return Notification.objects.filter(user=user, is_read=False).update(is_read=True)
