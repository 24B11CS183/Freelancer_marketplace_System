from django.shortcuts import render, get_object_or_404, redirect
from django.views import View
from django.views.generic import ListView
from django.contrib.auth.mixins import LoginRequiredMixin
from django.contrib import messages
from .models import Notification
from .utils import mark_as_read, mark_all_user_notifications_as_read

class NotificationListView(LoginRequiredMixin, ListView):
    """
    Renders a list of the user's notifications, ordered by date.
    """
    model = Notification
    template_name = 'notifications/notification_list.html'
    context_object_name = 'notifications'
    paginate_by = 10

    def get_queryset(self):
        return Notification.objects.filter(user=self.request.user).order_by('-created_at')


class MarkNotificationAsReadView(LoginRequiredMixin, View):
    """
    Marks a single notification as read and redirects back to the notification list.
    """
    def post(self, request, pk, *args, **kwargs):
        notification = get_object_or_404(Notification, id=pk, user=request.user)
        mark_as_read(notification.id)
        messages.success(request, "Notification marked as read.")
        return redirect('notifications:notification_list')


class MarkAllNotificationsAsReadView(LoginRequiredMixin, View):
    """
    Marks all unread notifications for the user as read.
    """
    def post(self, request, *args, **kwargs):
        mark_all_user_notifications_as_read(request.user)
        messages.success(request, "All notifications marked as read.")
        return redirect('notifications:notification_list')
