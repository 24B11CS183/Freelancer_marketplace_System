from django.contrib import admin
from .models import Notification

class NotificationAdmin(admin.ModelAdmin):
    """
    Admin configuration for the Notification model.
    Allows easy tracking, filtering, and review of system-wide notifications.
    """
    list_display = ['user', 'title', 'is_read', 'created_at']
    search_fields = ['user__email', 'user__username', 'title', 'message']
    list_filter = ['is_read', 'created_at']

admin.site.register(Notification, NotificationAdmin)
