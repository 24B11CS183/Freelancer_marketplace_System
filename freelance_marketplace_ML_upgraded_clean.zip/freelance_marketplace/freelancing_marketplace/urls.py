from django.contrib import admin
from django.urls import path, include
from django.conf import settings
from django.conf.urls.static import static
from django.views.generic import TemplateView

urlpatterns = [
    path('admin/', admin.site.urls),
    path('', TemplateView.as_view(template_name='home.html'), name='home'),
    
    # App URLs routing namespaces
    path('accounts/', include('accounts.urls')),
    path('clients/', include('clients.urls')),
    path('freelancers/', include('freelancers.urls')),
    path('projects/', include('projects.urls')),
    path('proposals/', include('proposals.urls')),
    path('messaging/', include('messaging.urls')),
    path('payments/', include('payments.urls')),
    path('notifications/', include('notifications.urls')),
    path('admin-dashboard/', include('admin_dashboard.urls')),
    path('ml-recommendations/', include('ml_recommendation.urls')),
]

# Serve static/media assets in development environment
if settings.DEBUG:
    urlpatterns += static(settings.MEDIA_URL, document_root=settings.MEDIA_ROOT)
    urlpatterns += static(settings.STATIC_URL, document_root=settings.STATIC_ROOT)
