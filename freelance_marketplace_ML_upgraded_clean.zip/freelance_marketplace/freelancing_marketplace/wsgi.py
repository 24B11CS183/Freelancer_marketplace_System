import os
from django.core.wsgi import get_wsgi_application

os.environ.setdefault('DJANGO_SETTINGS_MODULE', 'freelancing_marketplace.settings')

# Use uppercase APPLICATION to match settings.WSGI_APPLICATION
APPLICATION = get_wsgi_application()
