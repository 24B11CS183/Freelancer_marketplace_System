import os
from django.core.asgi import get_asgi_application

os.environ.setdefault('DJANGO_SETTINGS_MODULE', 'freelancing_marketplace.settings')

# Use uppercase APPLICATION to match settings.ASGI_APPLICATION
APPLICATION = get_asgi_application()
