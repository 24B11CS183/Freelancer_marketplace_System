from django.shortcuts import render, redirect, get_object_or_404
from django.urls import reverse_lazy
from django.views.generic import TemplateView, ListView, DetailView, UpdateView
from core.mixins import FreelancerRequiredMixin
from django.contrib.auth.mixins import LoginRequiredMixin
from proposals.models import Proposal
from payments.models import Payment, Invoice
from django.contrib import messages
from .models import FreelancerProfile
from .forms import FreelancerProfileForm

class FreelancerDashboardView(FreelancerRequiredMixin, TemplateView):
    """
    Renders the Freelancer Dashboard, presenting key metrics like
    total proposals submitted, active gigs, and earnings from invoices.
    """
    template_name = 'freelancers/dashboard.html'

    def get_context_data(self, **kwargs):
        context = super().get_context_data(**kwargs)
        user = self.request.user
        
        # Ensure a profile is associated with the user
        profile, created = FreelancerProfile.objects.get_or_create(user=user)
        
        # Gather metrics
        freelancer_proposals = Proposal.objects.filter(freelancer=user)
        context['total_proposals'] = freelancer_proposals.count()
        context['accepted_proposals'] = freelancer_proposals.filter(status='ACCEPTED').count()
        context['pending_proposals'] = freelancer_proposals.filter(status='PENDING').count()
        
        # Retrieve payments to calculate total earnings
        payments = Payment.objects.filter(freelancer=user, payment_status='Paid')
        context['earnings'] = sum([pay.project_budget for pay in payments])
        
        context['recent_proposals'] = freelancer_proposals.order_by('-id')[:5]
        context['profile'] = profile
        
        # Active projects for the freelancer
        context['active_proposals_list'] = freelancer_proposals.filter(
            status='ACCEPTED',
            project__status__in=['HIRED', 'IN_PROGRESS']
        ).select_related('project', 'project__client')
        
        return context


class FreelancerProfileDetailView(LoginRequiredMixin, DetailView):
    """
    Displays the public profile details of a freelancer, showing their bio, skills, and rates.
    """
    model = FreelancerProfile
    template_name = 'freelancers/profile_detail.html'
    context_object_name = 'profile'
    
    def get_object(self, queryset=None):
        pk = self.kwargs.get('pk')
        if pk:
            return get_object_or_404(FreelancerProfile, pk=pk)
        return get_object_or_404(FreelancerProfile, user=self.request.user)

    def get_context_data(self, **kwargs):
        context = super().get_context_data(**kwargs)
        profile = self.get_object()
        
        # Fetch freelancer reviews
        from admin_dashboard.models import Review
        reviews = Review.objects.filter(reviewee=profile.user, is_spam=False).select_related('reviewer')
        context['reviews'] = reviews
        
        # Calculate average rating
        from django.db.models import Avg
        avg_rating = reviews.aggregate(Avg('rating'))['rating__avg']
        context['average_rating'] = round(avg_rating, 1) if avg_rating else None
        
        return context


class FreelancerProfileUpdateView(FreelancerRequiredMixin, UpdateView):
    """
    Enables freelancers to modify their professional details like rates and bio.
    """
    model = FreelancerProfile
    form_class = FreelancerProfileForm
    template_name = 'freelancers/profile_edit.html'
    success_url = reverse_lazy('freelancers:dashboard')

    def get_object(self, queryset=None):
        profile, created = FreelancerProfile.objects.get_or_create(user=self.request.user)
        return profile

    def form_valid(self, form):
        messages.success(self.request, "Freelancer profile updated successfully.")
        return super().form_valid(form)


class FreelancerPortfolioView(LoginRequiredMixin, TemplateView):
    """
    Renders portfolio links and showcase details for the freelancer.
    """
    template_name = 'freelancers/portfolio.html'
    
    def get_context_data(self, **kwargs):
        context = super().get_context_data(**kwargs)
        # Fetch the current user profile or another freelancer by uuid
        pk = self.kwargs.get('pk')
        if pk:
            context['profile'] = get_object_or_404(FreelancerProfile, pk=pk)
        else:
            context['profile'] = get_object_or_404(FreelancerProfile, user=self.request.user)
        return context


class FreelancerSkillsView(LoginRequiredMixin, TemplateView):
    """
    Renders a dedicated page summarizing the freelancer's skill sets and experiences.
    """
    template_name = 'freelancers/skills.html'
    
    def get_context_data(self, **kwargs):
        context = super().get_context_data(**kwargs)
        pk = self.kwargs.get('pk')
        if pk:
            context['profile'] = get_object_or_404(FreelancerProfile, pk=pk)
        else:
            context['profile'] = get_object_or_404(FreelancerProfile, user=self.request.user)
        return context
