import uuid
from django.db import models
from django.conf import settings

class FreelancerProfile(models.Model):
    """
    Model representing professional details for users with the 'freelancer' role.
    """
    id = models.UUIDField(primary_key=True, default=uuid.uuid4, editable=False)
    user = models.OneToOneField(
        settings.AUTH_USER_MODEL, 
        on_delete=models.CASCADE, 
        related_name='freelancer_profile'
    )
    title = models.CharField(max_length=255, blank=True, null=True)
    skills = models.TextField(help_text="Comma-separated skills list. e.g. Python, Django, HTML5", blank=True, null=True)
    experience = models.TextField(help_text="Brief professional work history...", blank=True, null=True)
    hourly_rate = models.DecimalField(max_digits=10, decimal_places=2, default=0.00)
    portfolio_link = models.URLField(blank=True, null=True)
    resume = models.FileField(upload_to='resumes/', blank=True, null=True)

    def __str__(self):
        return self.title or f"Freelancer: {self.user.username}"

    def get_skills_list(self):
        """
        Helper method to parse comma-separated skills list into a python list.
        """
        if self.skills:
            return [skill.strip() for skill in self.skills.split(',') if skill.strip()]
        return []
