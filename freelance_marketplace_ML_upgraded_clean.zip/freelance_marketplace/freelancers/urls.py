from django.urls import path
from . import views

app_name = 'freelancers'

urlpatterns = [
    path('dashboard/', views.FreelancerDashboardView.as_view(), name='dashboard'),
    path('profile/', views.FreelancerProfileDetailView.as_view(), name='profile'),
    path('profile/<uuid:pk>/', views.FreelancerProfileDetailView.as_view(), name='profile_detail'),
    path('profile/edit/', views.FreelancerProfileUpdateView.as_view(), name='profile_edit'),
    path('portfolio/', views.FreelancerPortfolioView.as_view(), name='portfolio'),
    path('portfolio/<uuid:pk>/', views.FreelancerPortfolioView.as_view(), name='portfolio_detail'),
    path('skills/', views.FreelancerSkillsView.as_view(), name='skills'),
    path('skills/<uuid:pk>/', views.FreelancerSkillsView.as_view(), name='skills_detail'),
]
