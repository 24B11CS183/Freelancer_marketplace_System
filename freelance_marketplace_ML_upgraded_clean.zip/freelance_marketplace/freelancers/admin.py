from django.contrib import admin
from .models import FreelancerProfile

class FreelancerProfileAdmin(admin.ModelAdmin):
    """
    Admin configuration for FreelancerProfile model.
    Enables tracking of freelancer titles, hourly rates, and skills in the admin panel.
    """
    list_display = ['user', 'title', 'hourly_rate']
    search_fields = ['user__email', 'user__username', 'title', 'skills']
    list_filter = ['hourly_rate']

admin.site.register(FreelancerProfile, FreelancerProfileAdmin)
