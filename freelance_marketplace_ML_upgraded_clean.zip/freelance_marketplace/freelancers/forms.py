from django import forms
from .models import FreelancerProfile

class FreelancerProfileForm(forms.ModelForm):
    """
    Form for freelancers to update their professional profile details.
    """
    class Meta:
        model = FreelancerProfile
        fields = ('title', 'skills', 'experience', 'hourly_rate', 'portfolio_link', 'resume')
        widgets = {
            'title': forms.TextInput(attrs={'placeholder': 'e.g. Full-Stack Python Developer'}),
            'skills': forms.TextInput(attrs={
                'placeholder': 'e.g. Python, Django, REST Framework, React (comma separated)'
            }),
            'experience': forms.Textarea(attrs={
                'rows': 4, 
                'placeholder': 'Outline your past projects, positions, and technical milestones...'
            }),
            'hourly_rate': forms.NumberInput(attrs={'step': '1.00', 'placeholder': '50.00'}),
            'portfolio_link': forms.URLInput(attrs={'placeholder': 'https://portfolio.example.com'}),
        }
