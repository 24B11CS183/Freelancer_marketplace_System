from django import forms
from .models import Proposal

class ProposalForm(forms.ModelForm):
    """
    Form for submitting and modifying bids/proposals on project listings.
    """
    class Meta:
        model = Proposal
        fields = ('cover_letter', 'bid_amount', 'estimated_days')
        widgets = {
            'cover_letter': forms.Textarea(attrs={
                'rows': 5, 
                'placeholder': 'Explain why you are the best fit for this project. Outline your approach, relevant experience, and queries...'
            }),
            'bid_amount': forms.NumberInput(attrs={'step': '1.00', 'placeholder': '200.00'}),
            'estimated_days': forms.NumberInput(attrs={'placeholder': 'e.g. 5'}),
        }

    def clean_bid_amount(self):
        bid = self.cleaned_data.get('bid_amount')
        if bid is not None and bid <= 0:
            raise forms.ValidationError("Bid amount must be a positive currency amount.")
        return bid

    def clean_estimated_days(self):
        days = self.cleaned_data.get('estimated_days')
        if days is not None and days <= 0:
            raise forms.ValidationError("Estimated delivery days must be greater than zero.")
        return days
