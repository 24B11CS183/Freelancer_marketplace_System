from django.test import TestCase, RequestFactory
from django.contrib.auth import get_user_model
from django.urls import reverse
from datetime import date
from django.core.exceptions import PermissionDenied
from projects.models import Project
from proposals.models import Proposal
from proposals.views import SubmitProposalView
from projects.views import ProjectDetailView

User = get_user_model()

class ProposalSubmitTests(TestCase):
    def setUp(self):
        self.factory = RequestFactory()
        self.client_user = User.objects.create_user(
            username="client_user",
            email="client@example.com",
            password="password123",
            role="client"
        )
        self.other_client = User.objects.create_user(
            username="other_client",
            email="other_client@example.com",
            password="password123",
            role="client"
        )
        self.freelancer_user = User.objects.create_user(
            username="freelancer",
            email="freelancer@example.com",
            password="password123",
            role="freelancer"
        )
        self.project = Project.objects.create(
            client=self.client_user,
            title="Premium Job",
            description="Build a high performance web application.",
            budget=1500.00,
            category="DEVELOPMENT",
            skills_required="Django, Python",
            deadline=date(2026, 12, 31)
        )

    def test_freelancer_can_access_proposal_submit(self):
        request = self.factory.get(reverse('proposals:submit_proposal', kwargs={'project_id': self.project.pk}))
        request.user = self.freelancer_user
        
        # Instantiate view and call dispatch/get_context_data
        view = SubmitProposalView()
        view.request = request
        view.kwargs = {'project_id': self.project.pk}
        
        view.dispatch(request, project_id=self.project.pk)
        context = view.get_context_data()
        self.assertEqual(context['project'], self.project)

    def test_client_cannot_access_proposal_submit(self):
        request = self.factory.get(reverse('proposals:submit_proposal', kwargs={'project_id': self.project.pk}))
        request.user = self.other_client
        
        view = SubmitProposalView()
        view.request = request
        view.kwargs = {'project_id': self.project.pk}
        
        with self.assertRaises(PermissionDenied):
            view.dispatch(request, project_id=self.project.pk)

    def test_project_detail_view_context_for_roles(self):
        # 1. Test Freelancer details context
        request = self.factory.get(reverse('projects:project_detail', kwargs={'pk': self.project.pk}))
        request.user = self.freelancer_user
        view = ProjectDetailView()
        view.request = request
        view.kwargs = {'pk': self.project.pk}
        response = view.get(request, pk=self.project.pk)
        self.assertEqual(response.status_code, 200)

        # 2. Test Other Client details context
        request = self.factory.get(reverse('projects:project_detail', kwargs={'pk': self.project.pk}))
        request.user = self.other_client
        view = ProjectDetailView()
        view.request = request
        view.kwargs = {'pk': self.project.pk}
        response = view.get(request, pk=self.project.pk)
        self.assertEqual(response.status_code, 200)
