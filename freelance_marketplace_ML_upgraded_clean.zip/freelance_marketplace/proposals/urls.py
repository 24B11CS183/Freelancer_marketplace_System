from django.urls import path
from . import views

app_name = 'proposals'

urlpatterns = [
    path('project/<uuid:project_id>/submit/', views.SubmitProposalView.as_view(), name='submit_proposal'),
    path('<uuid:pk>/', views.ProposalDetailView.as_view(), name='proposal_detail'),
    path('<uuid:pk>/accept/', views.AcceptProposalView.as_view(), name='accept_proposal'),
    path('<uuid:pk>/reject/', views.RejectProposalView.as_view(), name='reject_proposal'),
]
