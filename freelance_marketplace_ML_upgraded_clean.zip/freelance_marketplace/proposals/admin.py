from django.contrib import admin
from .models import Proposal

class ProposalAdmin(admin.ModelAdmin):
    """
    Admin configuration for the Proposal model.
    Allows easy tracking, filtering, and review of freelancer project bids.
    """
    list_display = ['project', 'freelancer', 'bid_amount', 'estimated_days', 'status', 'created_at']
    search_fields = ['project__title', 'freelancer__email', 'freelancer__username', 'cover_letter']
    list_filter = ['status', 'estimated_days', 'created_at']

admin.site.register(Proposal, ProposalAdmin)
