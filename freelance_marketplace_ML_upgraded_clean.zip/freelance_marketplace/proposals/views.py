from django.shortcuts import render, redirect, get_object_or_404
from django.views import View
from django.views.generic import CreateView, DetailView
from django.contrib.auth.mixins import LoginRequiredMixin
from django.urls import reverse
from django.contrib import messages
from core.mixins import FreelancerRequiredMixin, ClientRequiredMixin
from projects.models import Project
from .models import Proposal
from .forms import ProposalForm

class SubmitProposalView(FreelancerRequiredMixin, CreateView):
    """
    Enables freelancers to submit a project bid/proposal.
    Ensures listings are currently OPEN and verifies they have not bid previously.
    """
    model = Proposal
    form_class = ProposalForm
    template_name = 'proposals/submit_proposal.html'

    def dispatch(self, request, *args, **kwargs):
        self.project = get_object_or_404(Project, pk=self.kwargs.get('project_id'))
        
        # Ensure project is accepting bids
        if self.project.status != 'OPEN':
            messages.error(request, "This project is no longer accepting proposals.")
            return redirect('projects:project_detail', pk=self.project.pk)
            
        # Ensure no duplicate bids
        if Proposal.objects.filter(project=self.project, freelancer=request.user).exists():
            messages.warning(request, "You have already submitted a proposal for this project.")
            return redirect('projects:project_detail', pk=self.project.pk)
            
        return super().dispatch(request, *args, **kwargs)

    def form_valid(self, form):
        form.instance.project = self.project
        form.instance.freelancer = self.request.user
        messages.success(self.request, "Your proposal has been submitted successfully!")
        return super().form_valid(form)

    def get_context_data(self, **kwargs):
        context = super().get_context_data(**kwargs)
        context['project'] = self.project
        return context

    def get_success_url(self):
        return reverse('projects:project_detail', kwargs={'pk': self.project.pk})


class ProposalDetailView(LoginRequiredMixin, DetailView):
    """
    Shows individual bid details.
    Ensures only the bidding freelancer or the client who posted the project can view this.
    """
    model = Proposal
    template_name = 'proposals/proposal_detail.html'
    context_object_name = 'proposal'

    def dispatch(self, request, *args, **kwargs):
        proposal = self.get_object()
        if request.user != proposal.project.client and request.user != proposal.freelancer:
            messages.error(request, "You do not have permission to view this proposal.")
            return redirect('projects:project_list')
        return super().dispatch(request, *args, **kwargs)


class AcceptProposalView(ClientRequiredMixin, View):
    """
    Enables clients to accept a proposal.
    Triggers project status to IN_PROGRESS, auto-rejects other bids,
    and generates a corresponding Invoice.
    """
    def post(self, request, pk, *args, **kwargs):
        proposal = get_object_or_404(Proposal, pk=pk)
        
        # Verify ownership of listing
        if request.user != proposal.project.client:
            messages.error(request, "Unauthorized action.")
            return redirect('projects:project_detail', pk=proposal.project.pk)
            
        if proposal.project.status != 'OPEN':
            messages.error(request, "This project is not open.")
            return redirect('projects:project_detail', pk=proposal.project.pk)

        # Accept selected proposal
        proposal.status = 'ACCEPTED'
        proposal.save()

        # Update Project Status
        project = proposal.project
        project.status = 'IN_PROGRESS'
        project.save()

        # Reject all other proposals for this project
        Proposal.objects.filter(project=project).exclude(pk=proposal.pk).update(status='REJECTED')

        # Auto-create Pending Payment record
        from payments.models import Payment
        Payment.objects.create(
            project=project,
            client=project.client,
            freelancer=proposal.freelancer,
            project_name=project.title,
            client_name=project.client.username,
            freelancer_name=proposal.freelancer.username,
            project_budget=project.budget,
            payment_status='Pending'
        )

        # Auto-create Invoice record
        from payments.models import Invoice
        from core.utils import generate_unique_invoice_number
        Invoice.objects.create(
            invoice_number=generate_unique_invoice_number(),
            client=project.client,
            freelancer=proposal.freelancer,
            amount=proposal.bid_amount
        )

        messages.success(
            request, 
            f"Proposal from {proposal.freelancer.username} accepted! Project is now In Progress."
        )


        return redirect('projects:project_detail', pk=project.pk)


class RejectProposalView(ClientRequiredMixin, View):
    """
    Enables clients to decline proposals.
    """
    def post(self, request, pk, *args, **kwargs):
        proposal = get_object_or_404(Proposal, pk=pk)
        
        # Verify ownership
        if request.user != proposal.project.client:
            messages.error(request, "Unauthorized action.")
            return redirect('projects:project_detail', pk=proposal.project.pk)

        proposal.status = 'REJECTED'
        proposal.save()

        messages.info(request, "Proposal marked as rejected.")
        return redirect('projects:project_detail', pk=proposal.project.pk)
