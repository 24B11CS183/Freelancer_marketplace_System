from django.shortcuts import render, get_object_or_404, redirect
from django.views import View
from django.views.generic import ListView
from django.contrib.auth.mixins import LoginRequiredMixin
from django.contrib import messages
from projects.models import Project
from proposals.models import Proposal
from .models import Payment, Invoice

class ProcessPaymentView(LoginRequiredMixin, View):
    """
    Processes simulated payment for a project after submission is approved.
    Sets Payment Status to Paid and stores the payment date.
    """
    def post(self, request, project_id, *args, **kwargs):
        project = get_object_or_404(Project, pk=project_id)
        
        # Verify the user is the client who posted the project
        if request.user != project.client:
            messages.error(request, "You do not have permission to pay for this project.")
            return redirect('projects:project_detail', pk=project.pk)
            
        # Verify project is in COMPLETED status (approved) and not yet paid
        if project.status != 'COMPLETED':
            messages.warning(request, "This project cannot be paid for yet as it has not been completed/approved.")
            return redirect('projects:project_detail', pk=project.pk)
            
        if project.is_paid:
            messages.warning(request, "This project has already been paid.")
            return redirect('projects:project_detail', pk=project.pk)
            
        # Find or create Payment record
        payment = Payment.objects.filter(project=project).first()
        if not payment:
            # Fallback if no payment was created yet
            proposal = project.proposals.filter(status='ACCEPTED').first()
            freelancer = proposal.freelancer if proposal else None
            payment = Payment.objects.create(
                project=project,
                client=project.client,
                freelancer=freelancer,
                project_name=project.title,
                client_name=project.client.username,
                freelancer_name=freelancer.username if freelancer else '',
                project_budget=project.budget,
                payment_status='Pending'
            )
            
        # Mark Payment Status = Paid and set datetime
        import django.utils.timezone
        payment.payment_status = 'Paid'
        payment.payment_date = django.utils.timezone.now()
        payment.save()
        
        # Sync and mark corresponding Invoice as paid
        try:
            invoice = Invoice.objects.filter(
                client=project.client,
                freelancer=payment.freelancer,
                is_paid=False
            ).first()
            if invoice:
                invoice.is_paid = True
                invoice.save()
        except Exception:
            pass
        
        messages.success(
            request, 
            f"Payment of ₹{project.budget} processed successfully! Funds released to freelancer."
        )
        return redirect('payments:client_dashboard_payments')


class PaymentHistoryView(LoginRequiredMixin, ListView):
    """
    Displays payment history for the logged-in client or freelancer.
    """
    model = Payment
    template_name = 'payments/payment_history.html'
    context_object_name = 'payments'
    paginate_by = 10

    def get_queryset(self):
        user = self.request.user
        if user.display_role == 'admin':
            return Payment.objects.all().order_by('-payment_date')
        elif user.role == 'client':
            return Payment.objects.filter(client=user).order_by('-payment_date')
        elif user.role == 'freelancer':
            return Payment.objects.filter(freelancer=user).order_by('-payment_date')
        return Payment.objects.none()

    def get_context_data(self, **kwargs):
        context = super().get_context_data(**kwargs)
        # Add old invoices for backwards compatibility if needed
        context['invoices'] = Invoice.objects.none()
        return context


class ClientDashboardPaymentsView(LoginRequiredMixin, ListView):
    """
    Renders Client Dashboard -> Payments tab page listing projects and their payment statuses.
    """
    model = Project
    template_name = 'payments/client_payments.html'
    context_object_name = 'projects'

    def get_queryset(self):
        queryset = Project.objects.filter(
            client=self.request.user,
            status__in=['HIRED', 'IN_PROGRESS', 'COMPLETED']
        ).order_by('-created_at')
        
        # Dynamically set is_paid status for template checks
        for p in queryset:
            p.is_paid = Payment.objects.filter(project=p, payment_status='Paid').exists()
            
        return queryset


class InvoiceDetailView(LoginRequiredMixin, View):
    """
    Placeholder view for InvoiceDetail to prevent breaking URLs in other apps.
    """
    def get(self, request, pk, *args, **kwargs):
        return redirect('payments:payment_history')
