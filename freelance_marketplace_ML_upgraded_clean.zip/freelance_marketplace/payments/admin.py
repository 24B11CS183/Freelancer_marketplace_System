from django.contrib import admin
from .models import Payment, Invoice

class PaymentAdmin(admin.ModelAdmin):
    """
    Admin configuration for the Payment model.
    Tracks transaction references, status, and project associations.
    """
    list_display = ['id', 'project', 'project_name', 'client_name', 'freelancer_name', 'project_budget', 'payment_status', 'payment_date']
    search_fields = ['project_name', 'client_name', 'freelancer_name', 'id']
    list_filter = ['payment_status', 'payment_date']


class InvoiceAdmin(admin.ModelAdmin):
    """
    Admin configuration for the Invoice model.
    Provides columns for paid tracking and invoice number details.
    """
    list_display = ['invoice_number', 'client', 'freelancer', 'amount', 'is_paid', 'created_at']
    search_fields = ['invoice_number', 'client__email', 'client__username', 'freelancer__email', 'freelancer__username']
    list_filter = ['is_paid', 'created_at']

admin.site.register(Payment, PaymentAdmin)
admin.site.register(Invoice, InvoiceAdmin)
