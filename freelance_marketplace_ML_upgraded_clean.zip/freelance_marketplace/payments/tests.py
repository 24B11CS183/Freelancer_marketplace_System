from django.test import TestCase
from django.contrib.auth import get_user_model
from django.urls import reverse
from datetime import date
from projects.models import Project
from proposals.models import Proposal
from payments.models import Payment

User = get_user_model()

class PaymentWorkflowTests(TestCase):
    def setUp(self):
        # Create users
        self.client_user = User.objects.create_user(
            username="client_test",
            email="client_test@example.com",
            password="password123",
            role="client"
        )
        self.freelancer_user = User.objects.create_user(
            username="freelancer_test",
            email="freelancer_test@example.com",
            password="password123",
            role="freelancer"
        )
        self.other_user = User.objects.create_user(
            username="other_test",
            email="other_test@example.com",
            password="password123",
            role="client"
        )

        # Create project
        self.project = Project.objects.create(
            client=self.client_user,
            title="Logo Design",
            description="Create a professional corporate logo.",
            budget=500.00,
            deadline=date(2026, 12, 31),
            status="HIRED"
        )

        # Create accepted proposal
        self.proposal = Proposal.objects.create(
            project=self.project,
            freelancer=self.freelancer_user,
            cover_letter="I can design a great logo.",
            bid_amount=500.00,
            estimated_days=3,
            status="ACCEPTED"
        )

    def test_client_can_pay_for_hired_project(self):
        # Create pending payment record as would happen on hiring
        Payment.objects.create(
            project=self.project,
            client=self.client_user,
            freelancer=self.freelancer_user,
            project_name=self.project.title,
            client_name=self.client_user.username,
            freelancer_name=self.freelancer_user.username,
            project_budget=self.project.budget,
            payment_status='Pending'
        )
        self.project.status = "COMPLETED"
        self.project.save()

        # Log in as the project owner (client)
        self.client.login(email="client_test@example.com", password="password123")
        url = reverse('payments:process_payment', kwargs={'project_id': self.project.pk})
        
        # Post to Pay Now
        response = self.client.post(url)
        self.assertRedirects(response, reverse('payments:client_dashboard_payments'))
        
        # Verify payment details saved
        self.assertEqual(Payment.objects.count(), 1)
        payment = Payment.objects.first()
        self.assertEqual(payment.project, self.project)
        self.assertEqual(payment.client, self.client_user)
        self.assertEqual(payment.freelancer, self.freelancer_user)
        self.assertEqual(payment.project_name, "Logo Design")
        self.assertEqual(payment.client_name, "client_test")
        self.assertEqual(payment.freelancer_name, "freelancer_test")
        self.assertEqual(payment.project_budget, 500.00)
        self.assertEqual(payment.payment_status, "Paid")
        
        # Verify project status remains COMPLETED
        self.project.refresh_from_db()
        self.assertEqual(self.project.status, "COMPLETED")

    def test_unauthorized_user_cannot_pay(self):
        # Create pending payment record
        payment = Payment.objects.create(
            project=self.project,
            client=self.client_user,
            freelancer=self.freelancer_user,
            project_name=self.project.title,
            client_name=self.client_user.username,
            freelancer_name=self.freelancer_user.username,
            project_budget=self.project.budget,
            payment_status='Pending'
        )
        self.project.status = "COMPLETED"
        self.project.save()

        # Log in as other client
        self.client.login(email="other_test@example.com", password="password123")
        url = reverse('payments:process_payment', kwargs={'project_id': self.project.pk})
        
        response = self.client.post(url)
        self.assertEqual(response.status_code, 302)
        
        # Verify payment status is still Pending and project status remains COMPLETED
        payment.refresh_from_db()
        self.assertEqual(payment.payment_status, "Pending")
        self.project.refresh_from_db()
        self.assertEqual(self.project.status, "COMPLETED")

    def test_payment_history_displays_correctly(self):
        # Create a payment
        Payment.objects.create(
            project=self.project,
            client=self.client_user,
            freelancer=self.freelancer_user,
            project_name=self.project.title,
            client_name=self.client_user.username,
            freelancer_name=self.freelancer_user.username,
            project_budget=self.project.budget,
            payment_status="Paid"
        )

        # 1. Test Client view
        self.client.login(email="client_test@example.com", password="password123")
        url = reverse('payments:payment_history')
        response = self.client.get(url)
        self.assertEqual(response.status_code, 200)
        self.assertTemplateUsed(response, 'payments/payment_history.html')
        self.assertEqual(len(response.context['payments']), 1)
        self.assertContains(response, "Logo Design")
        self.assertContains(response, "freelancer_test")
        self.assertContains(response, "₹500")

        # 2. Test Freelancer view
        self.client.login(email="freelancer_test@example.com", password="password123")
        response_f = self.client.get(url)
        self.assertEqual(response_f.status_code, 200)
        self.assertContains(response_f, "client_test")
        self.assertContains(response_f, "Paid")
