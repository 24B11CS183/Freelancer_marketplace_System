from django.urls import path
from . import views

app_name = 'payments'

urlpatterns = [
    path('history/', views.PaymentHistoryView.as_view(), name='payment_history'),
    path('pay/<uuid:project_id>/', views.ProcessPaymentView.as_view(), name='process_payment'),
    path('dashboard-payments/', views.ClientDashboardPaymentsView.as_view(), name='client_dashboard_payments'),
    path('invoice/<uuid:pk>/', views.InvoiceDetailView.as_view(), name='invoice_detail'),
]
