from django import forms
from .models import ClientProfile

class ClientProfileForm(forms.ModelForm):
    """
    Form for clients to update their company profile information.
    """
    class Meta:
        model = ClientProfile
        fields = ('company_name', 'company_description', 'website')
        widgets = {
            'company_name': forms.TextInput(attrs={'placeholder': 'Acme Corporation'}),
            'company_description': forms.Textarea(attrs={
                'rows': 4, 
                'placeholder': 'Tell freelancers about your company, culture, and projects...'
            }),
            'website': forms.URLInput(attrs={'placeholder': 'https://example.com'}),
        }
