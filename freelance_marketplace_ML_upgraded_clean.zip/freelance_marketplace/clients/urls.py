from django.urls import path
from . import views

app_name = 'clients'

urlpatterns = [
    path('dashboard/', views.ClientDashboardView.as_view(), name='dashboard'),
    path('profile/edit/', views.ClientProfileUpdateView.as_view(), name='profile_edit'),
    path('project/new/', views.PostProjectView.as_view(), name='post_project'),
    path('projects/', views.MyProjectsView.as_view(), name='my_projects'),
    path('hired-freelancers/', views.HiredFreelancersView.as_view(), name='hired_freelancers'),
]
