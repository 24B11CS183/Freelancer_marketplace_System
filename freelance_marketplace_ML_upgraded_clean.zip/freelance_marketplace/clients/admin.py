from django.contrib import admin
from .models import ClientProfile

class ClientProfileAdmin(admin.ModelAdmin):
    """
    Admin configuration for ClientProfile model.
    Allows easy search and filtering of client company profiles.
    """
    list_display = ['user', 'company_name', 'website']
    search_fields = ['user__email', 'user__username', 'company_name']
    list_filter = ['company_name']

admin.site.register(ClientProfile, ClientProfileAdmin)
