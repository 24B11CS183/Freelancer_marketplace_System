from django.shortcuts import render, redirect, get_object_or_404
from django.urls import reverse_lazy
from django.views.generic import TemplateView, CreateView, ListView, UpdateView
from core.mixins import ClientRequiredMixin
from projects.models import Project, ProjectSubmission
from proposals.models import Proposal
from django.contrib import messages
from .models import ClientProfile
from .forms import ClientProfileForm
from projects.forms import ProjectForm

class ClientDashboardView(ClientRequiredMixin, TemplateView):
    """
    Renders the Client Dashboard page, providing metrics like
    total projects posted, ongoing projects, proposals, and recent project entries.
    """
    template_name = 'clients/dashboard.html'

    def get_context_data(self, **kwargs):
        context = super().get_context_data(**kwargs)
        user = self.request.user
        
        # Ensure a profile is associated with the user
        client_profile, created = ClientProfile.objects.get_or_create(user=user)
        
        # Gather metrics
        client_projects = Project.objects.filter(client=user).select_related('client')
        
        context['total_projects'] = client_projects.count()
        context['active_projects'] = client_projects.filter(status__in=['HIRED', 'IN_PROGRESS']).count()
        context['open_projects'] = client_projects.filter(status='OPEN').count()
        context['proposals_count'] = Proposal.objects.filter(project__client=user).count()
        context['recent_projects'] = client_projects.order_by('-created_at')[:5]
        context['client_profile'] = client_profile
        
        # Gather submitted work deliveries
        context['submitted_works'] = ProjectSubmission.objects.filter(
            project__client=user
        ).select_related('project', 'freelancer').order_by('-submitted_at')
        
        return context




class ClientProfileUpdateView(ClientRequiredMixin, UpdateView):
    """
    Allows clients to edit their business/company specific settings.
    """
    model = ClientProfile
    form_class = ClientProfileForm
    template_name = 'clients/profile_edit.html'
    success_url = reverse_lazy('clients:dashboard')

    def get_object(self, queryset=None):
        profile, created = ClientProfile.objects.get_or_create(user=self.request.user)
        return profile

    def form_valid(self, form):
        messages.success(self.request, "Company profile updated successfully.")
        return super().form_valid(form)


class PostProjectView(ClientRequiredMixin, CreateView):
    """
    Enables clients to create a new project listing.
    """
    model = Project
    form_class = ProjectForm
    template_name = 'clients/post_project.html'
    success_url = reverse_lazy('clients:my_projects')

    def form_valid(self, form):
        # Automatically assign the logged in user as the client
        form.instance.client = self.request.user
        messages.success(self.request, "Project listed successfully!")
        return super().form_valid(form)


class MyProjectsView(ClientRequiredMixin, ListView):
    """
    Lists all projects posted by the logged-in client.
    """
    model = Project
    template_name = 'clients/my_projects.html'
    context_object_name = 'projects'
    paginate_by = 10

    def get_queryset(self):
        return Project.objects.filter(client=self.request.user).order_by('-id')


class HiredFreelancersView(ClientRequiredMixin, ListView):
    """
    Lists all freelancers hired by the client based on accepted proposals.
    """
    model = Proposal
    template_name = 'clients/hired_freelancers.html'
    context_object_name = 'accepted_proposals'
    paginate_by = 10

    def get_queryset(self):
        # Fetch accepted proposals for projects belonging to the client
        return Proposal.objects.filter(
            project__client=self.request.user, 
            status='ACCEPTED'
        ).select_related('freelancer', 'project')
