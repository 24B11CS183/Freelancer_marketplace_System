from django.apps import AppConfig


class MlRecommendationConfig(AppConfig):
    default_auto_field = 'django.db.models.BigAutoField'
    name = 'ml_recommendation'
    verbose_name = 'ML Freelancer Recommendation'
