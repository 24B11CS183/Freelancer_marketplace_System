from django.urls import path
from . import views

app_name = 'ml_recommendation'

urlpatterns = [
    path('project/<uuid:project_id>/', views.FreelancerRecommendationView.as_view(), name='project_recommendations'),
    path('projects/', views.ProjectRecommendationView.as_view(), name='project_recommendations_for_freelancer'),
]
