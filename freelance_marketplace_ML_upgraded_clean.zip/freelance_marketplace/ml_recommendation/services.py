"""ML-based recommendation services for the freelance marketplace.

The system uses TF-IDF + cosine similarity for text/skill matching and adds
simple numerical compatibility features for experience, bid, delivery time,
and budget. The final score uses fixed, explainable weights; these weights are
not learned from historical data.
"""

import re
from datetime import date
from decimal import Decimal
from typing import Dict, List, Optional

from sklearn.feature_extraction.text import TfidfVectorizer
from sklearn.metrics.pairwise import cosine_similarity

from freelancers.models import FreelancerProfile
from projects.models import Project
from proposals.models import Proposal


def _clean_text(value: str) -> str:
    value = value or ""
    value = value.lower()
    value = re.sub(r"[^a-z0-9+#.\- ]+", " ", value)
    return re.sub(r"\s+", " ", value).strip()


def _project_text(project) -> str:
    skills = project.skills_required or ""
    return _clean_text(
        f"{project.title} {project.description} {project.category or ''} "
        f"{skills} {skills}"
    )


def _freelancer_text(profile) -> str:
    skills = profile.skills or ""
    return _clean_text(
        f"{profile.title or ''} {profile.user.bio or ''} {skills} {skills} "
        f"{profile.experience or ''}"
    )


def _extract_years(text: str) -> Optional[float]:
    match = re.search(r"(\d+(?:\.\d+)?)\s*\+?\s*(?:years?|yrs?)", text or "", re.I)
    return float(match.group(1)) if match else None


def _experience_score(profile, project) -> float:
    freelancer_years = _extract_years(profile.experience or "")
    required_years = _extract_years(project.description or "")

    if freelancer_years is None or required_years is None:
        return 0.5
    if freelancer_years >= required_years:
        return 1.0
    return max(0.0, freelancer_years / required_years)


def _budget_score(project, proposal: Optional[Proposal]) -> float:
    if proposal is not None:
        budget = float(project.budget or 0)
        bid = float(proposal.bid_amount or 0)
        if budget <= 0 or bid <= 0:
            return 0.5
        if bid <= budget:
            return 1.0
        return max(0.0, budget / bid)

    # Before a proposal exists, use the freelancer's hourly rate as a rough
    # affordability signal. It is deliberately treated as a weak feature.
    return 0.5


def _delivery_score(project, proposal: Optional[Proposal]) -> float:
    if proposal is None:
        return 0.5

    days_available = (project.deadline - date.today()).days
    estimated_days = int(proposal.estimated_days or 0)

    if estimated_days <= 0 or days_available <= 0:
        return 0.0
    if estimated_days <= days_available:
        return 1.0
    return max(0.0, days_available / estimated_days)


def _matched_skills(project_skills: str, freelancer_skills: str) -> List[str]:
    required = {
        _clean_text(skill): skill.strip()
        for skill in (project_skills or "").split(",")
        if _clean_text(skill)
    }
    available = {
        _clean_text(skill): skill.strip()
        for skill in (freelancer_skills or "").split(",")
        if _clean_text(skill)
    }
    return [available[key] for key in required if key in available]


def _score_item(text_score, experience_score, budget_score, delivery_score):
    """Return a 0-100 explainable hybrid recommendation score."""
    final = (
        0.55 * text_score
        + 0.20 * experience_score
        + 0.15 * budget_score
        + 0.10 * delivery_score
    )
    return round(final * 100, 1)


def recommend_freelancers(project, limit: int = 10) -> List[Dict]:
    """Recommend freelancers for a client project.

    Features:
    - 55% TF-IDF/cosine text and skill similarity
    - 20% experience compatibility
    - 15% budget/bid compatibility
    - 10% delivery-time compatibility
    """
    profiles = list(
        FreelancerProfile.objects.select_related("user")
        .filter(user__role="freelancer")
    )
    if not profiles:
        return []

    documents = [_project_text(project)] + [_freelancer_text(p) for p in profiles]
    if not any(documents):
        return []

    vectorizer = TfidfVectorizer(stop_words="english", ngram_range=(1, 2))
    matrix = vectorizer.fit_transform(documents)
    text_scores = cosine_similarity(matrix[0:1], matrix[1:]).flatten()

    recommendations = []
    for profile, text_score in zip(profiles, text_scores):
        proposal = Proposal.objects.filter(project=project, freelancer=profile.user).first()
        exp_score = _experience_score(profile, project)
        bid_score = _budget_score(project, proposal)
        delivery_score = _delivery_score(project, proposal)

        recommendations.append({
            "profile": profile,
            "proposal": proposal,
            "score": _score_item(text_score, exp_score, bid_score, delivery_score),
            "text_score": round(float(text_score) * 100, 1),
            "experience_score": round(exp_score * 100, 1),
            "budget_score": round(bid_score * 100, 1),
            "delivery_score": round(delivery_score * 100, 1),
            "matched_skills": _matched_skills(project.skills_required, profile.skills),
        })

    recommendations.sort(key=lambda item: item["score"], reverse=True)
    return recommendations[:limit]


def _project_budget_fit(project, profile) -> float:
    budget = float(project.budget or 0)
    hourly_rate = float(profile.hourly_rate or 0)
    if budget <= 0 or hourly_rate <= 0:
        return 0.5
    # A simple affordability signal assuming a 20-hour minimum project effort.
    estimated_cost = hourly_rate * 20
    if estimated_cost <= budget:
        return 1.0
    return max(0.0, budget / estimated_cost)


def recommend_projects(profile, limit: int = 10) -> List[Dict]:
    """Recommend open projects to a freelancer based on profile skills/text."""
    projects = list(
        Project.objects.filter(status="OPEN", is_approved=True)
        .exclude(client=profile.user)
        .select_related("client")
    )
    if not projects:
        return []

    documents = [_freelancer_text(profile)] + [_project_text(p) for p in projects]
    if not any(documents):
        return []

    vectorizer = TfidfVectorizer(stop_words="english", ngram_range=(1, 2))
    matrix = vectorizer.fit_transform(documents)
    text_scores = cosine_similarity(matrix[0:1], matrix[1:]).flatten()

    recommendations = []
    for project, text_score in zip(projects, text_scores):
        # The project description can contain a requested experience level.
        required_years = _extract_years(project.description or "")
        freelancer_years = _extract_years(profile.experience or "")
        if required_years is None or freelancer_years is None:
            exp_score = 0.5
        elif freelancer_years >= required_years:
            exp_score = 1.0
        else:
            exp_score = max(0.0, freelancer_years / required_years)

        budget_score = _project_budget_fit(project, profile)
        score = 0.75 * float(text_score) + 0.15 * exp_score + 0.10 * budget_score

        recommendations.append({
            "project": project,
            "score": round(score * 100, 1),
            "text_score": round(float(text_score) * 100, 1),
            "experience_score": round(exp_score * 100, 1),
            "budget_score": round(budget_score * 100, 1),
            "matched_skills": _matched_skills(profile.skills, project.skills_required),
        })

    recommendations.sort(key=lambda item: item["score"], reverse=True)
    return recommendations[:limit]
