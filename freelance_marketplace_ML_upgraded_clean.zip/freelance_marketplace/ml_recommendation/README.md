# ML Recommendation Feature

This feature adds two-way recommendations to the Django freelance marketplace.

## 1. Client -> Freelancer
For a client's project, freelancers are ranked using:

- 55% TF-IDF + cosine similarity of project/profile text and skills
- 20% experience compatibility
- 15% bid/budget compatibility
- 10% delivery-time compatibility

If a freelancer has already submitted a proposal, the recommendation uses the actual bid amount and estimated delivery days.
If no proposal exists, those two values use neutral compatibility values because no bid/time estimate is available yet.

## 2. Freelancer -> Project
For a freelancer, open projects are ranked using:

- 75% TF-IDF + cosine similarity
- 15% experience compatibility
- 10% budget compatibility

The project list is available at:

`/ml-recommendations/projects/`

## Important ML explanation

TF-IDF is the feature-extraction technique and cosine similarity is the text-similarity measure.
The final percentages are fixed, explainable scoring weights; they are not learned model parameters.
Therefore, this should be presented in a viva as a **content-based / hybrid recommendation system**, not as a supervised classifier trained on historical hiring data.

The original Django marketplace features and database models are unchanged.
