from django.contrib import messages
from django.contrib.auth.mixins import LoginRequiredMixin
from django.shortcuts import get_object_or_404
from django.views.generic import TemplateView

from core.mixins import ClientRequiredMixin, FreelancerRequiredMixin
from freelancers.models import FreelancerProfile
from projects.models import Project
from .services import recommend_freelancers, recommend_projects


class FreelancerRecommendationView(ClientRequiredMixin, TemplateView):
    """Show hybrid ML recommendations for a client's project."""

    template_name = 'ml_recommendation/recommendations.html'

    def dispatch(self, request, *args, **kwargs):
        self.project = get_object_or_404(
            Project, pk=self.kwargs['project_id'], client=request.user
        )
        return super().dispatch(request, *args, **kwargs)

    def get_context_data(self, **kwargs):
        context = super().get_context_data(**kwargs)
        try:
            recommendations = recommend_freelancers(self.project)
        except Exception as exc:
            recommendations = []
            messages.error(self.request, f"Recommendation service could not run: {exc}")

        context.update({
            'project': self.project,
            'recommendations': recommendations,
            'algorithm_name': 'TF-IDF + Cosine Similarity + Compatibility Scoring',
            'direction': 'client',
        })
        return context


class ProjectRecommendationView(FreelancerRequiredMixin, TemplateView):
    """Show open projects recommended for the logged-in freelancer."""

    template_name = 'ml_recommendation/project_recommendations.html'

    def get_context_data(self, **kwargs):
        context = super().get_context_data(**kwargs)
        profile, _ = FreelancerProfile.objects.get_or_create(user=self.request.user)
        try:
            recommendations = recommend_projects(profile)
        except Exception as exc:
            recommendations = []
            messages.error(self.request, f"Recommendation service could not run: {exc}")

        context.update({
            'profile': profile,
            'recommendations': recommendations,
            'algorithm_name': 'TF-IDF + Cosine Similarity + Profile Compatibility',
            'direction': 'freelancer',
        })
        return context
