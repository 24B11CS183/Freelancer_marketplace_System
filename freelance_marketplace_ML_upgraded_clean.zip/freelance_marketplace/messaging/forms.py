from django import forms
from .models import Message

class MessageForm(forms.ModelForm):
    """
    Form for sending text messages inside conversations.
    """
    class Meta:
        model = Message
        fields = ('content',)
        widgets = {
            'content': forms.Textarea(attrs={
                'rows': 2, 
                'placeholder': 'Type your message here...',
                'class': 'form-control',
                'id': 'chat-message-input'
            }),
        }
