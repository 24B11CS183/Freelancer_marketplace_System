from django.shortcuts import render, get_object_or_404, redirect
from django.views import View
from django.views.generic import ListView
from django.contrib.auth.mixins import LoginRequiredMixin
from django.contrib.auth import get_user_model
from django.urls import reverse
from django.contrib import messages
from .models import Conversation, Message
from .forms import MessageForm

User = get_user_model()

class InboxView(LoginRequiredMixin, ListView):
    """
    Displays the user's conversation threads, ordered by the latest activity.
    """
    model = Conversation
    template_name = 'messaging/inbox.html'
    context_object_name = 'conversations'
    paginate_by = 10

    def get_queryset(self):
        # Fetch conversations where the user is a participant
        return Conversation.objects.filter(participants=self.request.user).order_by('-updated_at')


class ChatRoomView(LoginRequiredMixin, View):
    """
    Handles rendering the message history in a conversation,
    marking incoming items as read, and submitting new text messages.
    """
    def get(self, request, pk, *args, **kwargs):
        conversation = get_object_or_404(Conversation, pk=pk, participants=request.user)
        messages_list = conversation.messages.order_by('timestamp')
        
        # Mark incoming unread messages as read
        messages_list.filter(receiver=request.user, is_read=False).update(is_read=True)
        
        form = MessageForm()
        other_participant = conversation.participants.exclude(id=request.user.id).first()
        
        return render(request, 'messaging/chat_room.html', {
            'conversation': conversation,
            'messages_list': messages_list,
            'form': form,
            'other_participant': other_participant
        })

    def post(self, request, pk, *args, **kwargs):
        conversation = get_object_or_404(Conversation, pk=pk, participants=request.user)
        form = MessageForm(request.POST)
        other_participant = conversation.participants.exclude(id=request.user.id).first()
        
        if form.is_valid():
            message = form.save(commit=False)
            message.conversation = conversation
            message.sender = request.user
            message.receiver = other_participant
            message.save()
            
            # Save conversation to update 'updated_at' timestamp
            conversation.save()
            
            return redirect('messaging:chat_room', pk=conversation.pk)
            
        messages_list = conversation.messages.order_by('timestamp')
        return render(request, 'messaging/chat_room.html', {
            'conversation': conversation,
            'messages_list': messages_list,
            'form': form,
            'other_participant': other_participant
        })


class StartConversationView(LoginRequiredMixin, View):
    """
    Starts a conversation thread with another user.
    Retrieves an existing conversation if one exists, otherwise creates a new one.
    """
    def get(self, request, user_id, *args, **kwargs):
        recipient = get_object_or_404(User, id=user_id)
        if recipient == request.user:
            messages.warning(request, "You cannot start a conversation with yourself.")
            return redirect('messaging:inbox')
            
        # Look for an existing conversation between these two exact users
        conversation = Conversation.objects.filter(participants=request.user).filter(participants=recipient).first()
        
        if not conversation:
            # Create a new conversation container and link participants
            conversation = Conversation.objects.create()
            conversation.participants.add(request.user, recipient)
            
        return redirect('messaging:chat_room', pk=conversation.pk)
