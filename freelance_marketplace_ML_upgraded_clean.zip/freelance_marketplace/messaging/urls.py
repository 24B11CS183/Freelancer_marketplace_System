from django.urls import path
from . import views

app_name = 'messaging'

urlpatterns = [
    path('inbox/', views.InboxView.as_view(), name='inbox'),
    path('chat/<uuid:pk>/', views.ChatRoomView.as_view(), name='chat_room'),
    path('start/<uuid:user_id>/', views.StartConversationView.as_view(), name='start_conversation'),
]
