from django.contrib import admin
from .models import Conversation, Message

class ConversationAdmin(admin.ModelAdmin):
    """
    Admin configuration for the Conversation model.
    """
    list_display = ['id', 'created_at', 'updated_at']
    search_fields = ['id', 'participants__email', 'participants__username']
    list_filter = ['created_at', 'updated_at']


class MessageAdmin(admin.ModelAdmin):
    """
    Admin configuration for the Message model.
    Provides easy content inspection and status checking.
    """
    list_display = ['sender', 'receiver', 'content_excerpt', 'timestamp', 'is_read']
    search_fields = ['sender__email', 'sender__username', 'receiver__email', 'receiver__username', 'content']
    list_filter = ['is_read', 'timestamp']

    def content_excerpt(self, obj):
        return obj.content[:50] + '...' if len(obj.content) > 50 else obj.content
    content_excerpt.short_description = 'Content Excerpt'

admin.site.register(Conversation, ConversationAdmin)
admin.site.register(Message, MessageAdmin)
