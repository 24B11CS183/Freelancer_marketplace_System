import uuid
import datetime

def generate_unique_invoice_number():
    """
    Generates a unique invoice identifier string.
    Format: INV-YYYYMMDD-XXXX where XXXX is a unique alphanumeric code.
    """
    date_str = datetime.date.today().strftime('%Y%m%d')
    unique_suffix = str(uuid.uuid4())[:4].upper()
    return f"INV-{date_str}-{unique_suffix}"


def calculate_platform_fee(amount, rate=0.05):
    """
    Calculates the service/platform fee (default 5%) for payments.
    """
    try:
        val = float(amount)
        return round(val * rate, 2)
    except (TypeError, ValueError):
        return 0.0
