from django.contrib.auth.mixins import LoginRequiredMixin, UserPassesTestMixin
from django.core.exceptions import PermissionDenied

class ClientRequiredMixin(LoginRequiredMixin, UserPassesTestMixin):
    """
    Mixin for Class-Based Views that ensures the current user is authenticated
    and has the 'client' role.
    """
    def test_func(self):
        return self.request.user.is_authenticated and self.request.user.display_role == 'client'
        
    def handle_no_permission(self):
        if not self.request.user.is_authenticated:
            # Redirect to login page
            return super().handle_no_permission()
        # Raise 403 Forbidden
        raise PermissionDenied("Only clients are allowed to access this view.")


class FreelancerRequiredMixin(LoginRequiredMixin, UserPassesTestMixin):
    """
    Mixin for Class-Based Views that ensures the current user is authenticated
    and has the 'freelancer' role.
    """
    def test_func(self):
        return self.request.user.is_authenticated and self.request.user.display_role == 'freelancer'
        
    def handle_no_permission(self):
        if not self.request.user.is_authenticated:
            # Redirect to login page
            return super().handle_no_permission()
        # Raise 403 Forbidden
        raise PermissionDenied("Only freelancers are allowed to access this view.")
